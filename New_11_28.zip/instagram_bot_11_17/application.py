import os
import random
import time
import datetime
from datetime import timedelta
from flask import Flask, request, jsonify
from celery import Celery
from celery.task.control import revoke
from celery.exceptions import Ignore
from instagrambot import RestFunc,update_bot
from bson.json_util import dumps


from pymongo import MongoClient
#client = MongoClient('127.0.0.1:27017')
client = MongoClient('localhost:27017')
db = client.InstagramCrawl
#fs = gridfs.GridFS( db )



app = Flask(__name__)

# Celery configuration
#broker_url = 'amqp://vahidamiri:hh@localhost:5672/instabot'
app.config['CELERY_BROKER_URL'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/insta_bot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/insta_bot'

# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)



@celery.task(bind=True)
def instagram_bot_task(self,*args,**kwargs):

    username = args[0]
    password=args[1]
    aut_man=args[2]
    BotName=args[3]
    period=args[4]
    crawl_usernames=args[5]
    dl_image=args[6]
    import json

    if period != 'n':

        while True:

            try:
                date = str(datetime.datetime.now())
                message=BotName + ' ' + "Started at %s"  %date
                self.update_state(state='STARTED', meta={'message': message})
                time.sleep(1)
                self.update_state(state='PROGRESS')
                time.sleep(1)
                R = RestFunc(username=username, password=password, aut_man=aut_man, BotName=BotName, dl_image=dl_image,crawl_usernames=crawl_usernames)
            except Exception as e:
                self.update_state(state='FAILURE', meta={'message': e})
                return jsonify({'message': str(e)})

            if R == True:
                period_date = periodCal(kind=period)
                t = bot_sleep_time(period_date)
                message = BotName + ' ' + 'was crawled, %s will start again at' % BotName + ' ' + period_date
                self.update_state(state='PROGRESS', meta={'message': message})
                time.sleep(t)
            else:
                self.update_state(state='FAILURE', meta={'message': R})
                return jsonify({'message': str(R)})

    else:
        date = str(datetime.datetime.now())
        message = BotName + ' ' + "Started at %s" % date
        self.update_state(state='STARTED', meta={'message': message})
        time.sleep(1)
        self.update_state(state='PROGRESS')
        time.sleep(1)

        try:
            R = RestFunc(username=username, password=password, aut_man=aut_man, BotName=BotName, dl_image=dl_image,crawl_usernames=crawl_usernames)
        except Exception as e:
            self.update_state(state='FAILURE', meta={'message': e})
            return jsonify({'message': str(e)})

        if R == True:
            date = str(datetime.datetime.now())
            message = BotName + ' ' + 'was crawled at %s ' + date
            self.update_state(state='SUCCESS',meta={'message':message})
            return jsonify({'status': 'Task completed!'})
        else:
            self.update_state(state='FAILURE', meta={'message': R})
            return jsonify({'message': str(R)})

    self.update_state(state='PROGRESS')
    time.sleep(1)
    return jsonify({'status': 'Task completed!'})




@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()

    username=data['username']
    password=data['password']
    aut_man=data['aut_man']
    botname=data['botname']
    period=data['period']
    users=data['users']
    dl_image=data['dl_image']


    task = instagram_bot_task.apply_async(args= [username,password, aut_man,botname,
	         period,users,dl_image])

    return jsonify({"task_id":task.id}), 202



@app.route('/graphquery', methods=['POST'])
def graphquery():
    data = request.get_json()

    user_a = data['user_a']
    user_b = data['user_b']

    try:
        data = result_neo4j(user_a=user_a, user_b=user_b)
        return jsonify({"data": data}), 202
    except:
        data = {"message":"somethings went wrong!"}
        return jsonify({"data": data}), 409




@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = instagram_bot_task.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': str(task.info)
        }
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)









@app.route('/update', methods=['POST'])
def update():
    data = request.get_json()

    aut_man = data['aut_man']
    botname = data['botname']
    users = data['users']
    dl_image = data['dl_image']

    u = update_bot(botname=botname,crawl_usernames=users,dl_image=dl_image,aut_man=aut_man)

    if u == True:
        return jsonify({"message": "bot arguments is update"}), 202

    elif u == False:
        return jsonify({"message": "bot update was failed"}), 409

    else:
        return jsonify({"message": str(u)}), 409




@app.route('/addaccount/<variable>/', methods=['GET', 'POST'])
def addAccount(variable):
    if request.method == 'POST':

        data = request.get_json()
        username = data['username']
        password = data['password']
        name = data['name']

        if variable == 'add':
            try:
                user_insert = db.users.insert_one({"username": username, "password": password, "name": name})
            except Exception as e:
                return jsonify({"message": str(e)}), 400
            return jsonify({"message": "user added!"}), 202
        else:
            try:
                update = db.insta_bot_names.update_one({'username': username},{
                    "$set": {"password": password, "name": name}}, True, True)
                return jsonify({"message": "user was updated!"}), 202
            except Exception as e:
                return jsonify({"message": str(e)}), 400

    else:
        try:
            if variable == 'all':
                find_username = db.users.find()
                j = 0
                users = []
                for i in find_username:
                    users.append({"id": j, "username": i['username'], "password": i['password'], "name": i["name"]})
                    j = j + 1
            else:
                find_username = db.users.find({"username": variable})
                j = 0
                users = []
                for i in find_username:
                    users.append({"id": j, "username": i['username'], "password": i['password'], "name": i["name"]})
                    j = j + 1

        except Exception as e:
            return jsonify({"message": str(e)}), 400

        return jsonify({"meassge":users}),202



@app.route('/query/<variable>/', methods=['GET', 'POST'])
def query(variable):
    if request.method == 'POST':

        if variable == 'user':
            data = request.get_json()
            users = data['username']
            try:
                j = 0
                data = []
                for user in users:
                    find = db.instagram_users_info.find({"username":user})
                    c = 0
                    profile_data = []
                    for i in find:
                        profile_data.append({"id":c,"profile_data":i})
                        c = c + 1
                    data.append({"id":j,"user":user,"data":profile_data})
                    j = j + 1

            except Exception as e:
                return jsonify({"message": str(e)}), 400
            return jsonify({"message": data}), 202

        else:
            try:
                data = request.get_json()
                words = data['words']
                data =[]
                j = 0
                for word in words:
                    find = db.instagram_users_posts.find({"$text":{"$search": word}})
                    c = 0
                    word_data = []
                    for i in find:
                        word_data.append({"id": c, "data": i})
                        c = c + 1
                    data.append({"id": j, "word": word, "data": word_data})
                    j = j + 1


                return jsonify({"message": data}), 202
            except Exception as e:
                return jsonify({"message": str(e)}), 400

    else:
        try:
            if variable == 'alluser':
                profile_count = db.instagram_users_info.distinct("user_id").length
                data = {"data":int(profile_count)}

            else:
                data = {"data": "noting to show!"}

        except Exception as e:
            return jsonify({"message": str(e)}), 400

        return jsonify({"meassge":data}),202





if __name__ == '__main__':
    app.run('0.0.0.0',debug=True)
