#
# fri_list=[]
# for f in profile_id:
# 	if (f.isnumeric()):
# 		fri_list.append(f)
# 	else:
# 		sep = '?'
# 		rest = f.split(sep, 1)[0]
# 		fri = re.sub('?', '', rest)
# 		fri_list.append(fri.split('/')[-1])



tx= '82372'

print(tx.isnumeric())