from PIL import Image
import requests
import io
import datetime
import time
from pymongo import MongoClient
import gridfs
import time,shutil

def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 20, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total:
        print()




db = MongoClient().InstagramCrawl
fs = gridfs.GridFS( db )

def picToBinary(url):
    Picture_request = requests.get(url)
    if Picture_request.status_code == 200:
        return Picture_request.content

def gridfs_insert(data_path,collection):

    file = "r's%'" % data_path
    print(file)

    try:
        file_id = fs.put(open(file, 'rb'), collection=collection)
        os.remove(file)

    except Exception as e:
        print(e)
        file_id = ""

    return file_id

def gridfs_insert_db(img,file_name):

    try:
        file_id = fs.put(img, file_name=file_name)

    except Exception as e:
        print(e)
        file_id = ""

    return file_id

def image_optimizer(img):

    foo = Image.open(io.BytesIO(img))

    with io.BytesIO() as output:
        foo.save(output, optimize=True, quality=85,format='JPEG')
        return output.getvalue()



def save_bytes_to_image(bytes,file_path,name):

    fp = file_path + '/' + name
    f = open(fp, 'wb')
    f.write(bytes)
    f.close()


def image_dl_update(botname=None):
    while True:

        if botname == None:
            try:
                findC = db.instagram_users_posts.find({'image_dl': True, "img_download": False}).count()

            except Exception as e:
                print(e)
                findC = db.instagram_users_posts.count_documents({'image_dl': True, "img_download": False})

        else:
            try:
                findC = db.instagram_users_posts.find({'botName': botname, 'image_dl': True, "img_download": False}).count()

            except Exception as e:
                print(e)
                findC = db.instagram_users_posts.count_documents(
                    {'botName': botname, 'image_dl': True, "img_download": False})


        counter = 0
        while True:

            if findC == 0:
                time.sleep(3600)
                break

            if counter > findC:
                break
            

            if botname == None:
                find = db.instagram_users_posts.find({'image_dl': True, "img_download": False}).limit(100)
            else:
                find = db.instagram_users_posts.find(
                    {'botName': botname, 'image_dl': True, "img_download": False}).limit(
                    100)
            c= 0
            for i in find:
                #print(i)
                date = datetime.datetime.now()
                try:
                    img_list = i['image']
                    id = i['_id']
                    #print(id)
                    imageList = []
                    #img_list_len= len(img_list)
                    #g = 0
                    for im in img_list:
                        width = im['width']
                        height = im['height']
                        size = str(width) + '*' + str(height)
                        url = im['url']
                        b_image = picToBinary(url=url)
                        img_opt = image_optimizer(img=b_image)
                        imageList.append(gridfs_insert_db(img=img_opt, file_name=str(size)))
                        #g = g + 1
                        #printProgressBar(iteration=g, total=img_list_len, prefix="img download and opim")

                    try:
                        update = db.instagram_users_posts.update({'_id': id},{
                            "$set": {"img_download": True, 'imageList': imageList, 'date': date}},True,True)
                        #time.sleep(60)
                    except Exception as e:
                        print(e)
                    c = c + 1
                    printProgressBar(iteration=c, total=100,prefix="img list Update")
                except Exception as e:
                    print(e)
                    continue
