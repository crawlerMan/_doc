import os
import time
from flask import Flask, request,jsonify
from celery import Celery
from Telegram_scraper import authentication,main

#-------------MongoDB Config-------------#
from pymongo import MongoClient
mongo_client = MongoClient('localhost')
db = mongo_client.telegram
#--------------*****----------------------#

app = Flask(__name__)

# Celery configuration - rabbitmq
app.config['CELERY_BROKER_URL'] = 'amqp://vahidamiri:sara@localhost:5672/instabot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://vahidamiri:sara@localhost:5672/instabot'

# Celery configuration - mongodb
# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)


@celery.task(bind=True)
def bot_start(self,*args,**kwargs):
    api_id = args[0]
    api_hash=args[1]
    phone=args[2]
    BotName=args[3]
    period=args[4]
    manual=args[5]
    func=args[6]
    grLink=args[7]
    chLink=args[8]
    aut_code = args[9]

    if manual == False:
        grLink=None
        chLink=None


    x = main(bot_name=BotName,api_id=api_id,api_hash=api_hash,phone=phone,manual=manual,period=period,func=func,grLink=grLink,chLink=chLink,aut_code=aut_code)

    self.update_state(state='PROGRESS')
    time.sleep(1)
    return {'status': 'Task completed!'}



@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()
    api_id = data['api_id']
    api_hash = data['api_hash']
    phone = data['phone']
    BotName = data['BotName']
    period = data['period']
    manual = data['manual']
    func = data['func']
    aut_code=data['aut_code']
    grLink = data['grLink']
    chLink = data['chLink']

    mongo_data = {"api_id": api_id,"api_hash": api_hash,"phone": phone,"BotName": BotName,
     "period": period,"manual": manual,"aut_code": aut_code,"func": func,"grLink":grLink,"chLink": chLink}


    #i = db.telegram_bot.insert_one(mongo_data)
    time.sleep(1)
    x = authentication(api_id=api_id, api_hash=api_hash, phone=phone, bot_name=BotName, aut_code=aut_code)
    if x == 0:
        return jsonify({"message": "plz send aut code"}), 401
    if x == 3:
        return jsonify({"message": "aut code is not correct!"}), 401
    if x == 1:
        print("connect succesful")
        task = bot_start.apply_async(args=[api_id, api_hash, phone, BotName,
                                           period, manual, func, grLink, chLink, aut_code])
        return jsonify({"task_id":task.id}), 202
    x = str(x)
    return jsonify({"message": x}), 401




@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = bot_start.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': task.info.get('status', '')
        }
        if 'result' in task.info:
            response['result'] = task.info['result']
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)






if __name__ == '__main__':
    app.run(debug=True)
