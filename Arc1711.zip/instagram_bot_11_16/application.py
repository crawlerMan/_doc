import os
import random
import time
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from celery import Celery
from celery.task.control import revoke
from celery.exceptions import Ignore
from instagrambot import RestFunc


app = Flask(__name__)

# Celery configuration
#broker_url = 'amqp://vahidamiri:hh@localhost:5672/instabot'
app.config['CELERY_BROKER_URL'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/insta_bot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/insta_bot'

# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)

#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
    date = datetime.datetime.now()

    if kind == 'y':
        periodD = date + timedelta(days=365)

    if kind == 'm':
        periodD = date + timedelta(days=30)

    if kind == 'w':
        periodD = date + timedelta(days=7)

    if kind == 'd':
        periodD = date + timedelta(days=1)

    if kind == 'n':
        periodD = date

    return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#


#-------------- Neo4j Query function  ----------------------#

def result_neo4j(user_a,user_b):

	if type(user_a) and type(user_b) == int:
		cqlShorestPath = """MATCH (p1:Users { user_id: %d }),(p2:Users { user_id: %d }), 
								path = shortestPath((p1)-[*..500]-(p2))
								RETURN extract (n in nodes(path))""" % (user_a, user_b)

	else:
		cqlShorestPath = """MATCH (p1:Users { username: %d }),(p2:Users { username: %d }), 
								path = shortestPath((p1)-[*..500]-(p2))
								RETURN extract (n in nodes(path))""" % (user_a, user_b)

	result = gr.evaluate(cqlShorestPath)

	lenOfPath =len(result)
	path = []
	c = 0
	for i in result:
		path.append({'number': c, 'username': i['username'], 'user_id': i['user_id']})
		c = int(c) + 1

	data = {'from': user_a, 'to': user_b, 'len': lenOfPath, 'path': path}

	return data

#-------------- Neo4j Query function End ----------------------#

@celery.task(bind=True)
def instagram_bot_task(self,*args,**kwargs):

    username = args[0]
    password=args[1]
    aut_man=args[2]
    BotName=args[3]
    period=args[4]
    crawl_usernames=args[5]
    dl_image=args[6]
    import json

    if period != 'n':

        while True:

            try:
                date = str(datetime.datetime.now())
                message=BotName + ' ' + "Started at %s"  %date
                self.update_state(state='STARTED', meta={'message': message})
                time.sleep(1)
                self.update_state(state='PROGRESS')
                time.sleep(1)
                R = RestFunc(username=username, password=password, aut_man=aut_man, BotName=BotName, dl_image=dl_image,crawl_usernames=crawl_usernames)
            except ValueError as e:
                self.update_state(state='FAILURE', meta={'message': e})
                return Ignore()

            if R == True:
                period_date = periodCal(kind=period)
                t = bot_sleep_time(period_date)
                message = BotName + ' ' + 'was crawled, %s will start again at' % BotName + ' ' + period_date
                self.update_state(state='PROGRESS', meta={'message': message})
                time.sleep(t)
            else:
                self.update_state(state='FAILURE', meta={'message': R})
                return Ignore()

    else:
        date = str(datetime.datetime.now())
        message = BotName + ' ' + "Started at %s" % date
        self.update_state(state='STARTED', meta={'message': message})
        time.sleep(1)
        self.update_state(state='PROGRESS')
        time.sleep(1)

        try:
            R = RestFunc(username=username, password=password, aut_man=aut_man, BotName=BotName, dl_image=dl_image,crawl_usernames=crawl_usernames)
        except Exception as e:
            self.update_state(state='FAILURE', meta={'message': e})
            return Ignore()

        if R == True:
            date = str(datetime.datetime.now())
            message = BotName + ' ' + 'was crawled at %s ' + date
            self.update_state(state='SUCCESS',meta={'message':message})
            return {'status': 'Task completed!'}
        else:
            self.update_state(state='FAILURE', meta={'message': R})
            return Ignore()

    self.update_state(state='PROGRESS')
    time.sleep(1)
    return jsonify({'status': 'Task completed!'})




@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()

    username=data['username']
    password=data['password']
    aut_man=data['aut_man']
    botname=data['botname']
    period=data['period']
    users=data['users']
    dl_image=data['dl_image']


    task = instagram_bot_task.apply_async(args= [username,password, aut_man,botname,
	         period,users,dl_image])

    return jsonify({"task_id":task.id}), 202



@app.route('/graphquery', methods=['POST'])
def graphquery():
    data = request.get_json()

    user_a = data['user_a']
    user_b = data['user_b']

    try:
        data = result_neo4j(user_a=user_a, user_b=user_b)
        return jsonify({"data": data}), 202
    except:
        data = {"message":"somethings went wrong!"}
        return jsonify({"data": data}), 409




@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = instagram_bot_task.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': str(task.info)
        }
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)



@app.route('/qouery/<name>')
def qouery(name):
    if name == 'profile':

        dis =db.instagram_users.distinct('username').conut()
        response ={"count":int(dis)}

    if name == 'posts':

        dis = db.instagram_posts.distinct('media_id').conut()
        response = {"count": int(dis)}

    return jsonify(response)




if __name__ == '__main__':
    app.run('0.0.0.0',debug=True)
