import time,shutil
from datetime import timedelta
from persiantools.jdatetime import JalaliDateTime
import datetime
import time,shutil
import dateutil.parser
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv
import re
import os,pytz
from functools import partial
from Functions import removeStr,remove_emoji,lanqdet,spliteKeyWord,hashtaghEx
from textblob import TextBlob
import emoji

def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total:
        print()


#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
	date = datetime.datetime.now()

	if kind == 'y':
		periodD = date + timedelta(days=365)

	if kind == 'm':
		periodD = date + timedelta(days=30)

	if kind == 'w':
		periodD = date + timedelta(days=7)

	if kind == 'd':
		periodD = date + timedelta(days=1)

	return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#



# for i in range(1000):
# 	time.sleep(0.1)
# 	# Update Progress Bar
# 	printProgressBar(iteration=i, total=1000, prefix='Progress:', suffix='Complete')

#
def period_sleep(bot_name,sec):

	if sec < 86401:
		for i in range(0,sec,3600):
			printProgressBar(iteration=i, total=85038, prefix='==> %s bot:' % bot_name,
			                 suffix='Until next period (hours).',length = 24)
			time.sleep(3600)

	else:
		for i in range(0, sec,86400):
			printProgressBar(iteration=i, total=85038, prefix='==> %s bot:' % bot_name,
			                 suffix='Until next period (Days).',length = 100)
			time.sleep(86400)




print(bot_sleep_time(periodCal('d')))
print(bot_sleep_time(periodCal('w')))
print(bot_sleep_time(periodCal('m')))
print(bot_sleep_time(periodCal('y')))



# for i in range(0,518400,86400):
# 	printProgressBar(iteration=i, total=85038, prefix='==> Pause:',
# 	                 suffix='Hours until to next period.',length = 24)
# 	print(i)
# 	#time.sleep(3600)


period_sleep('sara',bot_sleep_time(periodCal('y')))
#period_sleep(bot_sleep_time(periodCal('y')))