import os
import random
import time
from flask import Flask, request, render_template, session, flash, redirect, \
    url_for, jsonify
from celery import Celery
from celery.task.control import revoke
from celery.exceptions import Ignore
from facebookscraper import main


app = Flask(__name__)

# Celery configuration
#broker_url = 'amqp://vahidamiri:hh@localhost:5672/instabot'
app.config['CELERY_BROKER_URL'] = 'amqp://celery_bot:HNADZBE@localhost:5672/fb_bot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://celery_bot:HNADZBE@localhost:5672/fb_bot'

# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)


@celery.task(bind=True)
def instagram_bot_task(self,*args,**kwargs):

    username = args[0]
    password=args[1]
    bot_name=args[2]
    auto_man=args[3]
    period=args[4]
    users=args[5]

    self.update_state(state='STARTED')
    time.sleep(1)
    R = main(username=username, password=password, bot_name=bot_name, aut_mua=auto_man,period=period, profile_list=users)
    self.update_state(state='PENDING')
    time.sleep(1)
    if R == True:
        self.update_state(state='SUCCESS')
        return {'status': 'Task completed!'}
    else:
        self.update_state(state='FAILURE', meta={'message': R})
        return Ignore()



@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()
    username = data['username']
    password = data['password']
    bot_name = data['botname']
    auto_man = data['auto_man']
    period = data['period']
    users = data['users']

    task = instagram_bot_task.apply_async(args= [username,password,bot_name,auto_man,period,users])

    return jsonify({"task_id":task.id}), 202



# @app.route('/revoke/<task_id>')
# def taskrevoke(task_id):
#     print(task_id)
#     revoke(task_id=task_id,terminate=True, signal='SIGKILL')
#     return jsonify({"message":"task was terminated"})


@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = instagram_bot_task.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': task.info.get('status', '')
        }
        if 'result' in task.info:
            response['result'] = task.info['result']
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)


if __name__ == '__main__':
    app.run(debug=True)
