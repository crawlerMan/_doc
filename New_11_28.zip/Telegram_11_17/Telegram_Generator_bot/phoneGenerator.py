import datetime
from datetime import timedelta
from tkinter import dialog
import time,shutil
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv


from pymongo import MongoClient
client = MongoClient('localhost')
db = client.telegram

session_path= '/Users/vahid/Downloads/New_update'



def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 50, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total:
        print()

def Aut(api_id,api_hash,phone):
	try:
		print("Connecting to Telegram...")
		client = TelegramClient(session=session_path, api_id=api_id, api_hash=api_hash)
		client.connect()
	except Exception as e:
		print("can't connect to telegram server")
		print(str(e))

	if not client.is_user_authorized():
		print("client is not connect")
		client.send_code_request(phone)
		try:
			client.sign_in(phone, input('Enter the code: '))
		except Exception as e:
			print(e)

		if client.is_user_authorized():
			print("client connected")
			return client



def entity(phoneNumber,client):



	number = str(phoneNumber)
	try:
		user = client.get_entity(number)

		try:
			if user.id:
				user_id = user.id
			else:
				user_id = ""

			if user.username:
				username = user.username
			else:
				username = ""

			if user.mutual_contact:
				mutual_contact = user.mutual_contact
			else:
				mutual_contact = ""

			if user.access_hash:
				access_hash = user.access_hash
			else:
				access_hash = ""

			data = {"Phone_number": phoneNumber,"telegram":True, "user_id": user_id, "username": username,
			        "mutual_contact": mutual_contact, "access_hash": access_hash}
			print(data)
			try:
				insert = db.telegram_phone_numbers.insert_one(data)
			except:
				print("somethings wrong in mongodb.")

		except:
			print("somthings wrong in fetch data")

	except:
		insert =db.not_telegram_phone_numbers.insert({"Phone_number":phoneNumber,"telegram":False})





def phone_checker():

	api_id = 796906
	api_hash = '80a4ef01149c6c639b815cafbd3aab49'
	phone = '989192683701'

	client_active = Aut(api_id,api_hash,phone)

	phone_numbers = db.phone_numbers.find({'telegram_check': False})

	try:
		len_phone_numbers = db.phone_numbers.find({'telegram_check': False}).count()
	except Exception as e:
		len_phone_numbers = db.phone_numbers.count_documents({'telegram_check': False})

	c = 0
	total = len_phone_numbers
	for i in phone_numbers:
		id = i['_id']
		phone_numbers_list = i['phone_number']
		for j in phone_numbers_list:
			try:
				entity(phoneNumber=int(j),client=client_active)
				time.sleep(2)
				date = datetime.datetime.now()
				update = db.phone_numbers.update_one({'_id': id},
				                                 {"$set": {'telegram_check': True, 'date': date}},
				                                 True, True)
			except Exception as e:
				print(e)
		c = c + 1
		printProgressBar(iteration=c, total=total, prefix="==> phone number checker",
		                 suffix='complete - %d phone number checked' % int(c * 20))
		if (c % 100) == 0:
			time.sleep(1800)





phone_checker()

