import os
import random
import time
from flask import Flask, request, render_template, session, flash, redirect, \
    url_for, jsonify
from celery import Celery
from celery.task.control import revoke
from instagrambot import RestFunc


app = Flask(__name__)

# Celery configuration
app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)


@celery.task(bind=True)
def lng_task(self,*args,**kwargs):
    username = args[0]
    password=args[1]
    loginStu=args[2]
    BotName=args[3]
    period=args[4]
    crawl_usernames=args[5]
    consolTarget=args[6]
    x = RestFunc(username=username, password=password, loginStu=loginStu, BotName=BotName,period=period, crawl_usernames=crawl_usernames, consolTarget=consolTarget)
    self.update_state(state='PROGRESS')
    time.sleep(1)
    return {'status': 'Task completed!'}



@app.route('/longtask', methods=['POST'])
def longtask():
    data = request.get_json()
    task = lng_task.apply_async(args= [data['username'],data['password'], data['status'],data['botname'],
	         data['period'],data['users'],2])
    return jsonify({"task_id":task.id}), 202



@app.route('/revoke/<task_id>')
def taskrevoke(task_id):
    revoke(task_id, terminate=True)
    return {"message":"task is terminate"}


@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = lng_task.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': task.info.get('status', '')
        }
        if 'result' in task.info:
            response['result'] = task.info['result']
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)


if __name__ == '__main__':
    app.run(debug=True)
