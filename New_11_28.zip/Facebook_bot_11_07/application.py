import os
import random
import time
from flask import Flask, request, render_template, session, flash, redirect, \
    url_for, jsonify
from celery import Celery
from celery.task.control import revoke
from celery.exceptions import Ignore
from facebookscraper import main,update_bot


app = Flask(__name__)

# Celery configuration
#broker_url = 'amqp://vahidamiri:hh@localhost:5672/instabot'
app.config['CELERY_BROKER_URL'] = 'amqp://celery_bot:HNADZBE@localhost:5672/fb_bot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://celery_bot:HNADZBE@localhost:5672/fb_bot'

# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)


@celery.task(bind=True)
def facebook_bot_task(self,*args,**kwargs):

    username = args[0]
    password=args[1]
    bot_name=args[2]
    auto_man=args[3]
    period=args[4]
    users=args[5]

    self.update_state(state='STARTED')
    time.sleep(1)
    R = main(username=username, password=password, bot_name=bot_name, aut_man=auto_man,period=period, profile_list=users)
    self.update_state(state='PENDING')
    time.sleep(1)
    if R == True:
        self.update_state(state='SUCCESS')
        return {'status': 'Task completed!'}
    else:
        self.update_state(state='FAILURE', meta={'message': R})
        return Ignore()



@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()
    username = data['username']
    password = data['password']
    bot_name = data['botname']
    auto_man = data['auto_man']
    period = data['period']
    users = data['users']

    task = facebook_bot_task.apply_async(args= [username,password,bot_name,auto_man,period,users])

    return jsonify({"task_id":task.id}), 202



# @app.route('/revoke/<task_id>')
# def taskrevoke(task_id):
#     print(task_id)
#     revoke(task_id=task_id,terminate=True, signal='SIGKILL')
#     return jsonify({"message":"task was terminated"})


@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = facebook_bot_task.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': task.info.get('status', '')
        }
        if 'result' in task.info:
            response['result'] = task.info['result']
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)

@app.route('/update', methods=['POST'])
def update():
    data = request.get_json()

    aut_man = data['aut_man']
    bot_name = data['bot_name']
    profile_list = data['users']
    period = data['period']

    u = update_bot(bot_name=bot_name,profile_list=profile_list,period=period,aut_man=aut_man)

    if u == True:
        return jsonify({"message": "bot arguments is update"}), 202

    elif u == False:
        return jsonify({"message": "bot update was failed"}), 409

    else:
        return jsonify({"message": str(u)}), 409

@app.route('/addaccount/<variable>/', methods=['GET', 'POST'])
def addAccount(variable):
    if request.method == 'POST':

        data = request.get_json()
        username = data['username']
        password = data['password']
        name = data['name']

        if variable == 'add':
            try:
                user_insert = db.users.insert_one({"username": username, "password": password, "name": name})
            except Exception as e:
                return jsonify({"message": str(e)}), 400
            return jsonify({"message": "user added!"}), 202
        else:
            try:
                update = db.insta_bot_names.update_one({'username': username},{
                    "$set": {"password": password, "name": name}}, True, True)
                return jsonify({"message": "user was updated!"}), 202
            except Exception as e:
                return jsonify({"message": str(e)}), 400

    else:
        try:
            if variable == 'all':
                find_username = db.users.find()
                j = 0
                users = []
                for i in find_username:
                    users.append({"id": j, "username": i['username'], "password": i['password'], "name": i["name"]})
                    j = j + 1
            else:
                find_username = db.users.find({"username": variable})
                j = 0
                users = []
                for i in find_username:
                    users.append({"id": j, "username": i['username'], "password": i['password'], "name": i["name"]})
                    j = j + 1

        except Exception as e:
            return jsonify({"message": str(e)}), 400

        return jsonify({"meassge":users}),202


@app.route('/query/<variable>/', methods=['GET', 'POST'])
def query(variable):
    if request.method == 'POST':

        data = request.get_json()
        users = data['username']

        if variable == 'user':
            try:
                j = 0
                data = []
                for user in users:
                    find = db.profile_scrap.find({"profile_id":user})
                    c = 0
                    profile_data = []
                    for i in find:
                        profile_data.append({"id":c,"profile_data":i})
                        c = c + 1
                    data.append({"id":j,"user":user,"data":profile_data})
                    j = j + 1


            except Exception as e:
                return jsonify({"message": str(e)}), 400
            return jsonify({"message": data}), 202
        else:
            try:
                data =[]
                j = 0
                for word in words:
                    find = db.profile_scrap.find({"$text":{"$search": word}})
                    c = 0
                    word_data = []
                    for i in find:
                        word_data.append({"id": c, "data": i})
                        c = c + 1
                    data.append({"id": j, "word": word, "data": word_data})
                    j = j + 1


                return jsonify({"message": data}), 202
            except Exception as e:
                return jsonify({"message": str(e)}), 400

    else:
        try:
            if variable == 'alluser':
                profile_count = db.profile_scrap.distinct("profile_id").length
                data = {"data":int(profile_count)}

            else:
                data = {"data": "noting to show!"}

        except Exception as e:
            return jsonify({"message": str(e)}), 400

        return jsonify({"meassge":data}),202





if __name__ == '__main__':
    app.run(debug=True)
