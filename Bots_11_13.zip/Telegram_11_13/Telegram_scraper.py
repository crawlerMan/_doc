from datetime import timedelta
from persiantools.jdatetime import JalaliDateTime
import datetime
import time,shutil
import dateutil.parser
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv
import re
import os,pytz
from functools import partial
from Functions import removeStr,remove_emoji,lanqdet,spliteKeyWord,hashtaghEx
from textblob import TextBlob
import emoji


#-------------MongoDB Config-------------#
from pymongo import MongoClient
#mongo_client = MongoClient('10.0.1.178:47017')
mongo_client = MongoClient('localhost:27017')
db = mongo_client.telegram
#--------------*****----------------------#

def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 50, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total:
        print()

#-------------------------------------------------------#

def period_sleep(bot_name,sec):

	if sec < 86401:
		for i in range(0,sec,3600):
			printProgressBar(iteration=i, total=85038, prefix='==> %s bot:' % bot_name,
			                 suffix='Until next period (Hours).',length = 24)
			time.sleep(3600)

	else:
		for i in range(0, sec,86400):
			printProgressBar(iteration=i, total=85038, prefix='==> %s bot:' % bot_name,
			                 suffix='Until next period (Days).',length = 100)
			time.sleep(86400)




#--------------Log maker function----------------------#

def logmaker(bot="telegram",bot_name='default',kind=" ",description=" "):
	date = JalaliDateTime.now(pytz.timezone("Asia/Tehran")).strftime("%c")
	title = "Date & Time:              " + "\t" + "Bot Name:" + "\t   " + "Kind:" + "   \t" + "Description:" + "\t" + "\n"
	log = str(date) + "\t    " + str(bot_name) + "    \t     " + str(kind) + "\t     " + str(description) + "\t" + "\n"

	if os.path.exists("%s_%s_Log.txt" % (bot_name, bot)):
		logFile = open("%s_%s_Log.txt" % (bot_name, bot), "a+")
		logFile.write(log)
		logFile.close()

	else:
		with open("%s_%s_Log.txt" % (bot_name, bot), "w") as NewlogFile:
			NewlogFile.write(title)
			NewlogFile.write(log)
			NewlogFile.close()



#--------------Log maker function End ----------------------#

#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
	date = datetime.datetime.now()

	if kind == 'y':
		periodD = date + timedelta(days=365)

	if kind == 'm':
		periodD = date + timedelta(days=30)

	if kind == 'w':
		periodD = date + timedelta(days=7)

	if kind == 'd':
		periodD = date + timedelta(days=1)

	return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#

#-------------Kafka Config----------------#

from confluent_kafka import Producer
import json

def kafkaproducer(jsn,topic,bot_name='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    pass
    #print(jsn)

def kafkaproducerN(jsn,topic,bot_name='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    data = str(jsn)

    def delivery_report(err, msg):
        """ Called once for each message produced to indicate delivery result.
            Triggered by poll() or flush(). """
        if err is not None:
            Kafkaerror='Message delivery failed: {}'.format(err)
            print(Kafkaerror)
            logmaker(bot="telegram", kind="error",bot_name=bot_name, description="kafka Message delivery failed - topic: %s " % topic)
            logmaker(bot="telegram", kind="error",bot_name=bot_name, description= Kafkaerror)

        else:
            print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))
    try:
        p = Producer({'bootstrap.servers': brokers})

    except:
        print("plz Check Kafka connections...")
        logmaker(bot="telegram", kind="error", bot_name=bot_name,description="kafka connections error ")
        time.sleep(10)
        pass

    try:
        # Trigger any available delivery report callbacks from previous produce() calls
        p.poll(0)
        p.produce(topic, data.encode('utf-8'), callback=delivery_report)

        p.flush()

    except:
        print("somethings wet wrong in kafka produce")
        logmaker(bot="telegram", kind="error", bot_name=bot_name,description="somethings wet wrong in kafka produce - topic: %s " % topic)

#--------------*****----------------------#

#--------------root path maker----------------------#


def mk_path(BotName='default'):

    bot_name_path = str(BotName)
    root_path = os.getcwd()
    root_path = root_path + '/telegram_bot'
    new_root_path = root_path + '/' + bot_name_path

    try:
        if os.path.exists(new_root_path):
            os.chdir(new_root_path)
        else:
            if os.path.exists(root_path):
                os.mkdir(new_root_path)
            else:
                os.mkdir(root_path)
                os.chdir(root_path)

                os.mkdir(new_root_path)
                os.chdir(new_root_path)

        print("Successfully open the directory %s " % new_root_path)
        logmaker(bot="telegram", kind="log", bot_name=BotName,
                 description="Successfully created the directory %s " % new_root_path)

        return new_root_path

    except OSError:
        print("Creation of the directory %s failed" % new_root_path)
        logmaker(bot="telegram", kind="error", bot_name=BotName,
                 description="Opening of the directory %s failed" % new_root_path)
#--------------root path maker end----------------------#

#session_path = '/root/bot/teleg_session'
session_path= '/Users/vahid/Downloads/New_update'
chats = []
last_date = None
chunk_size = 10000000
groups = []
channel = []


#estekhraj username_channels_groups
def extract_username(url):
    return re.search(r'https://t.me/([^/?]+)', url).group(1)

#estekhraj username_private_groups
def extract_pvgb_username(url):
    return re.search(r'https://t.me/joinchat/([^/?]+)', url).group(1)


#proxy = (socks.SOCKS5, '127.0.0.1', 9150)
import asyncio

def code_rec(code):
    return int(code)

def authentication(api_id,api_hash,phone,aut_code,bot_name):

    api_id = api_id
    api_hash = api_hash
    phone = phone
    session_path_main = session_path
    try:

        client = TelegramClient(session=session_path_main, api_id=api_id, api_hash=api_hash,loop=asyncio.set_event_loop(asyncio.new_event_loop()))
        client.connect()

        if aut_code == 0:
            if not client.is_user_authorized():
                client.send_code_request(phone=phone, force_sms=True)
                return 0
            else:
                client.start(phone=phone)

        else:
            try:

                if client.is_user_authorized():
                    client.start(phone=phone)
                    print("user is authorize")
                    return 1
                else:
                    client.start(phone=phone, force_sms=True, code_callback=partial(code_rec,aut_code))
                    if client.is_user_authorized():
                        print("user is authorize")
                        return 1

            except Exception as e:
                return e
    except Exception as e:
        return e



# ====================================گروه تلگرام==================
from telethon import errors
def telegramGroupExtract(client,limit=100,bot_name='default',groups=None,search=None,counter='n'):

    date = datetime.datetime.now()

    if groups !=None:

        for gr_l in groups:
            g = ''
            if extract_username(gr_l) == "joinchat":
                username = extract_pvgb_username(url=gr_l)
            else:
                username = extract_username(url=gr_l)
            try:
                updates = client(ImportChatInviteRequest(username))
                g = client.get_entity(gr_l)

            except Exception as e:
                logmaker(bot="telegram", bot_name=bot_name, kind="error", description="somethings was wrong 370 - error: %s" % e)
                print(e)
                g = client.get_entity(gr_l)
                pass

            print("strat fetching group < %s > " % g.title)

            members = []

            print("group < %s > crawl start..." % g.title)

            if g.id:
                group_id = g.id
            else:
                group_id = ''

            if g.username:
                group_username = g.username
            else:
                group_username = ''

            if g.title:
                group_title = g.title

            else:
                group_title = ''

            if g.date:
                group_create_date = g.date

            else:
                group_create_date = ''

            if g.access_hash:
                group_access_hash = g.access_hash

            else:
                group_access_hash = ''

            print('Fetching Members...')
            all_participants = []
            try:
                all_participants = client.get_participants(g, aggressive=True)
            except Exception as e:
                print (e)
            gr_members_len = len(all_participants)
            gr_mem_c: int = 0
            for user in all_participants:
                if user.username:
                    username = user.username
                else:
                    username = ""
                if user.id:
                    user_id = user.id
                else:
                    user_id = ""
                if user.phone:
                    phone_number = user.phone
                else:
                    phone_number = ""
                if user.first_name:
                    first_name = user.first_name
                else:
                    first_name = ""
                if user.last_name:
                    last_name = user.last_name
                else:
                    last_name = ""

                data_mem = {'bot_name': bot_name, "group_name": g.title, "group_id": g.id, "username": username,
                                "user_id": user_id, "first_name": first_name,
                                "last_name": last_name,
                                "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted,
                                'counter': counter, 'date': date}


                try:
                    insert_pe = db.telegram_group_people.insert_one(data_mem)
                    kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                      topic="telegram_bot")
                    gr_mem_c = gr_mem_c + 1
                    time.sleep(0.1)
                    printProgressBar(iteration=gr_mem_c, total=gr_members_len, prefix='==> Fetch members progress:', suffix='Complete')



                except Exception as e:
                    print(e)
                    print("somethings wrong in mongo connection-telegram_people")
                    logmaker(bot="telegram", bot_name=bot_name, kind="error",
                             description="somethings wrong in mongo connection-telegram_people 452 - error: %s" % e)

                members.append(data_mem)



                now = datetime.datetime.now()
                data = {'bot_name': bot_name, "group_id": int(group_id), "group_username": group_username,
                        "group_title": group_title,
                        "group_create_date": group_create_date, "group_access_hash": group_access_hash,
                        "is_crawl": False,
                        "members": members,
                        "fetch_date": now,
                        'counter': counter}
                #print("< %s > Informations: " % group_username)
                # print(data)

                try:
                    insert = db.groups_info.insert_one(data)
                    kafkaproducer({"collections": "groups_info", "data": data}, topic="telegram_bot")

                    # print('Saving In Database...')
                    # print('Members scraped successfully.')
                except Exception as e:
                    logmaker(bot="telegram", bot_name=bot_name, kind="error",
                             description="somethings wrong in mongo connection-group_info 481 - error: %s" % e)
                    print("somethings wrong in mongo connection-group_info")


            try:
                print("Start fetching last messages...")
                try:
                    messages = client.get_messages(g, limit, search=search)
                except Exception as e:
                    logmaker(bot="telegram", bot_name=bot_name, kind="error",
                             description="somethings wrongs 494 - error: %s" % e)
                    print(e)

                message_len=len(messages)
                message_c: int= 0
                for message in messages:

                    if message.message:
                        message_txt = message.message
                    else:
                        message_txt = ""

                    if message.from_id:
                        user_id = message.from_id
                    else:
                        user_id = ""

                    if message.reply_to_msg_id:
                        reply_to_id = message.reply_to_msg_id

                    else:
                        reply_to_id = ""

                    if message.fwd_from:
                        froward_from = message.fwd_from
                    else:
                        froward_from = ""

                    if message.date:
                        date = message.date
                    else:
                        date = ""
                    lanq = lanqdet(message_txt)
                    data_group = {'bot_name': bot_name, "group_name": g.title, "group_id": g.id,
                                  "message": message_txt, 'lanq': lanq,
                                  "from_user_id": user_id, "reply_to_id": reply_to_id,
                                  "froward_from": froward_from,
                                  "date": date, 'counter': counter}

                    try:
                        insert = db.groups_message_info.insert_one(data_group)
                        kafkaproducer({"collections": "groups_message_info", "data": data_group},
                                      topic="telegram_bot")
                        time.sleep(1)

                    except Exception as e:
                        logmaker(bot="telegram", bot_name=bot_name, kind="error",
                                 description="somethings wrong in mongo connection-groups_message_info 540 - error: %s" % e)
                        print(e)
                        print("somethings wrong in mongo connection-groups_message_info")

                    message_c = message_c + 1
                    time.sleep(0.1)
                    printProgressBar(iteration=message_c, total=message_len, prefix='==> Fetch messages progress:',
                                     suffix='Complete')

                print("All messages fetched...")



            except:
                print("somethings wrong in fetching groups...")
                pass
    else:
        print ('Groups list is empty (None)')



def channelExtract(client,limit=100,bot_name='default',channels=None,counter='n'):

    if channels != None:

        for username in channels:
            g = ''
            if extract_username(username) == "joinchat":
                username = extract_pvgb_username(url=username)
            else:
                username = extract_username(url=username)
            try:
                updates = client(ImportChatInviteRequest(username))
                g = client.get_entity(username)

            except Exception as e:
                print(e)
                g = client.get_entity(username)
                pass

            channel_entity = client.get_entity(g)
            channel_n = channel_entity.title

            ischannel = False
            messages = client.iter_messages(entity=channel_entity.title, limit=limit)
            print("Start fetching messages of channel %s." % channel_n)
            # message_len = len(messages)
            message_c: int = 0
            # print(messages)
            for k in messages:
                #print(k)
                if k.to_id.channel_id:
                    channel_id = k.to_id.channel_id
                else:
                    channel_id = ''
                if k.message:
                    message = k.message
                else:
                    message = ""

                if k.date:
                    date = k.date
                else:
                    date = ''

                if k.views:
                    views = k.views
                    ischannel = True
                else:
                    views = ''
                if channel_n:
                    channel_name = channel_n
                else:
                    channel_name = ''

                if ischannel:
                    lanq = lanqdet(message)
                    data = {'bot_name': bot_name, "channel_name": channel_name, "channel_id": channel_id,
                            "message": message, 'lanq': lanq,
                            "date": date,
                            "views": views,
                            'counter': counter}
                    insert = db.channel_posts.insert_one(data)
                    kafkaproducer({"collections": "channel_posts", "data": data},
                                  topic="telegram_bot")

                    message_c = message_c + 1
                    time.sleep(0.1)
                    printProgressBar(iteration=message_c, total=limit, prefix='==> Fetch messages progress:',
                                      suffix='Complete')


            print("All messages fetched...")



#==========================join to channel ==============================



def channel_queue(url=None):
    if url != None:
        username = extract_username(url)
        join = client(JoinChannelRequest(username))
        update = db.channel_queue.update({"url": url}, {"$set": {"is_join": True}}, upsert=True,
                                         multi=True)
    else:
        find = db.channel_queue.find({"is_join": False})
        try:
            for i in find:
                username = extract_username(i["url"])
                join = client(JoinChannelRequest(username))
                try:
                    update = db.channel_queue.update({"url": i["url"]}, {"$set": {"is_join": True}}, upsert=False,
                                                     multi=False)
                except:
                    print("somethings wrong - mongodb update")
        except:
            print("somethings wrong - join channel %s." % i)



# https://t.me/joinchat/AAAAAFFszQPyPEZ7wgxLtd
# ===========================join private group==================================

def join_private_group(url=None):
    if url !=None:
        username = extract_pvgb_username(url)
        try:
            updates = client(ImportChatInviteRequest(username))
            update = db.private_gb_queue.update({"url":url}, {"$set": {"is_join": True}}, upsert=True,
                                                multi=True)
        except:
            print("somethings wrong in join pv group")

    else:

        find = db.private_gb_queue.find({"is_join": False})
        for i in find:
            username = extract_pvgb_username(i["url"])

            try:
                join = client(ImportChatInviteRequest(username))
                try:
                    update = db.private_gb_queue.update({"url":i["url"]},{"$set":{"is_join": True}},upsert=False, multi=True)

                except:
                    print("somethings wrong - mongodb update")

            except:
                print("somethings wrong in join pv group %s." % username)
                pass



def start_resume(bot_name,grlink,period,chlink,limit_g,limit_c):
    date = datetime.datetime.now()
    try:
        bot_name_find = db.bot_names.find({"bot_name": bot_name}).count()
    except Exception as e:
        print(e)
        logmaker(bot_name=bot_name, kind="error",description="error: %s - 617" %str(e))

    if bot_name_find == 0:
        bot_name_insert = db.bot_names.insert_one({'bot_name': bot_name,'grlink':grlink,'chlink':chlink,'limit_g':limit_g,'limit_c':limit_c,'period':period, 'first_d': date, 'last_d': date, 'status': False, 'counter': 0})
        c = 0
        return 'start', c, grlink, chlink, limit_g,limit_c, period

    if bot_name_find > 0:
        bot_name_find = db.bot_names.find({'bot_name': bot_name})

        for i in bot_name_find:
            status  = i['status']
            counter = i['counter']
            grlink  = i['grlink']
            chlink  = i['chlink']
            limit_g = i['limit_g']
            limit_c = i['limit_c']
            period  = i['period']
            c = counter
            if status == True:
                try:
                    update = db.bot_names.update_one({'bot_name': bot_name}, {"$set": {"status": False, 'last_d': date}},True, True)
                except Excetion as e:
                    print (e)
                    logmaker(bot_name=bot_name,kind='error',description='somethings wrong in monog connections - error:s%' % str(e))
                c = counter
                return 'start', c
            else:
                return 'resume', c, grlink, chlink, limit_g,limit_c, period



def main(bot_name,api_id,api_hash,phone,search,period='n',grLink=[],chLink=[],limit_g=100,limit_c=100):

    session_path_main = session_path

    mk_path(BotName=bot_name)

    client = TelegramClient(session=session_path_main, api_id=api_id, api_hash=api_hash,
                            loop=asyncio.set_event_loop(asyncio.new_event_loop()))
    client.connect()
    #aut = authentication(api_id=api_id,api_hash=api_hash,phone=phone,aut_code = aut_code)




    if client.is_user_authorized():
        print("Connect succesfully")

        if period == 'n':
            status, counter,grlink, chlink, limit_g,limit_c, period = start_resume(bot_name=bot_name,grlink=grLink,period=period,chlink=chLink,limit_g=limit_g,limit_c=limit_c)
            newCounter = int(counter) + 1
            date = datetime.datetime.now()
            if len(grLink) > 0:
                if len(search) > 0:
                    telegramGroupExtract(client=client,limit=limit_g,bot_name=bot_name, groups=grLink, search=search,counter = newCounter)
                else:
                    telegramGroupExtract(client=client,limit=limit_g,bot_name=bot_name, groups=grLink,counter= newCounter)

            if len(chLink) > 0:
                channelExtract(client=client,limit=limit_c,bot_name=bot_name, channels=chLink,counter = newCounter)

            if len(grLink) == 0 and len(chLink) == 0:
                return 4
            try:
                update = db.bot_names.update_one({'bot_name': bot_name},
                                             {"$set": {"status": True, 'counter': newCounter, 'last_d': date}},
                                             True, True)
            except Exception as e:
                print (e)
                logmaker(bot_name=bot_name, kind='error',
                        description='somethings wrong in monog connections - error:s%' % str(e))

            return 5

        else:
            while True:
                status, counter,grlink, chlink, limit_g,limit_c, period = start_resume(bot_name=bot_name,grlink=grLink,period=period,chlink=chLink,limit_g=limit_g,limit_c=limit_c)
                newCounter = int(counter) + 1
                date = datetime.datetime.now()


                if len(grLink) > 0:
                    if len(search) > 0:
                        telegramGroupExtract(client=client,limit=limit_g, bot_name=bot_name, groups=grLink, search=search,
                                             counter=newCounter)
                    else:
                        telegramGroupExtract(client=client,limit=limit_g,bot_name=bot_name, groups=grLink,counter = newCounter)
                if len(chLink) > 0:
                    channelExtract(client=client,limit=limit_c,bot_name=bot_name, channels=chLink,counter = newCounter)

                if len(grLink) == 0 and len(chLink) == 0:
                    return 4
                try:
                    update = db.bot_names.update_one({'bot_name': bot_name},
                                                 {"$set": {"status": True, 'counter': newCounter, 'last_d': date}},

                                                 True, True)
                except Exception as e:
                    print (e)
                    logmaker(bot_name=bot_name, kind='error',
                             description='somethings wrong in monog connections - error:s%' % str(e))

                periodDate = periodCal(kind=period)
                period_sleep(bot_name=bot_name,sec=bot_sleep_time(period=periodDate))

    else:
        return 'client is not connect!'




#print(authentication(api_id=796906,api_hash="80a4ef01149c6c639b815cafbd3aab49",phone=989192683701,aut_code=95785,bot_name='sara'))
#print(main(bot_name='sara',api_id=796906,api_hash="80a4ef01149c6c639b815cafbd3aab49",phone=989192683701,period='w',grLink=[],chLink=["https://t.me/Eslahatnews"],search=[]))

