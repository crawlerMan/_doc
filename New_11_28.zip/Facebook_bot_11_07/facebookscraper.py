import getpass
import calendar
import os
import platform
import sys
import re
import datetime, pytz
import time
from persiantools.jdatetime import JalaliDateTime
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from Functions import removeStr,remove_emoji,lanqdet,spliteKeyWord,hashtaghEx



#-----------------------chrome driver path--------------------#
# Global Variables
chromedrive_path ="/Users/vahid/Downloads/chromedriver-2"
#-----------------------chrome driver path--------------------#

#-------------Neo4j Config-------------#
from py2neo import Node,Database, Graph,Relationship,NodeMatcher

gr = Graph(password='HNADZBE')
matcher = NodeMatcher(gr)
#-------------Neo4j Config End -------------#


#-----------------------MongoDB--------------------#
from pymongo import MongoClient

client = MongoClient('localhost')
db = client.facebookCrawl

def picToBinary(url):
    Picture_request = requests.get(url)
    if Picture_request.status_code == 200:
        return Picture_request.content

def gridfs_insert_db(img,file_name):

    try:
        file_id = fs.put(img, file_name=file_name)

    except Exception as e:
        print(e)
        file_id = ""

    return file_id

def image_optimizer(img):

    foo = Image.open(io.BytesIO(img))

    with io.BytesIO() as output:
        foo.save(output, optimize=True, quality=85,format='JPEG')
        return output.getvalue()


#-----------------------MongoDB--------------------#





# -------------------------------------------------------------



def removeStr(t):
    regex = re.compile(r'[\n]')
    t = regex.sub(' ',t)
    t = t.rstrip()
    return t



# whether to download photos or not
download_uploaded_photos = True
download_friends_photos = True

# whether to download the full image or its thumbnail (small size)
# if small size is True then it will be very quick else if its false then it will open each photo to download it
# and it will take much more time
friends_small_size = True
photos_small_size = True

total_scrolls = 5000
current_scrolls = 0
scroll_time = 5

old_height = 0


# -------------------------------------------------------------
# -------------------------------------------------------------

def get_facebook_images_url(img_links):
    urls = []

    for link in img_links:

        if link != "None":
            valid_url_found = False
            driver.get(link)

            try:
                while not valid_url_found:
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "spotlight")))
                    element = driver.find_element_by_class_name("spotlight")
                    img_url = element.get_attribute('src')

                    if img_url.find('.gif') == -1:
                        valid_url_found = True
                        urls.append(img_url)

            except EC.StaleElementReferenceException:
                urls.append(driver.find_element_by_class_name("spotlight").get_attribute('src'))

            except:
                print("Exception (facebook_image_downloader):", sys.exc_info()[0])
                pass

        else:
            urls.append("None")

    return urls


# -------------------------------------------------------------
# -------------------------------------------------------------

# takes a url and downloads image from that url
def image_downloader(img_links, folder_name,results):
    img_names = []

    try:
        # parent = os.getcwd()
        # try:
        #     folder = os.path.join(os.getcwd(), folder_name)
        #     if not os.path.exists(folder):
        #         os.mkdir(folder)
        #
        #     os.chdir(folder)
        # except:
        #     print("Error in changing directory")

        i = 0
        for link in img_links:
            #img_name = "None"
            img_name = str(results[i])


            try:
                img_name = img_name.split('/')[-1]
                img_name = str(img_name) + '.jpg'

            except:
                img_name = "None"

            img_names.append(img_name)
            i = i + 1

        # os.chdir(parent)
    except:
        print("Exception (image_downloader):", sys.exc_info()[0])

    return img_names


# -------------------------------------------------------------
# -------------------------------------------------------------

def check_height():
    new_height = driver.execute_script("return document.body.scrollHeight")
    return new_height != old_height


# -------------------------------------------------------------
# -------------------------------------------------------------

# helper function: used to scroll the page
def scroll():
    global old_height
    current_scrolls = 0

    while (True):
        try:
            if current_scrolls == total_scrolls:
                return

            old_height = driver.execute_script("return document.body.scrollHeight")
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            WebDriverWait(driver, scroll_time, 0.05).until(lambda driver: check_height())
            current_scrolls += 1
        except TimeoutException:
            break

    return


# -------------------------------------------------------------
# -------------------------------------------------------------

#joda kardan kalamat
def seeMoreRem(query):
    stopwords = ['see', 'more', 'See', 'More', 'See more', 'See More']
    querywords = query.split()

    resultwords = [word for word in querywords if word.lower() not in stopwords]
    result = ' '.join(resultwords)

    return result

# --Helper Functions for Posts

def get_status(x):
    status = ""
    o = x
    link = ""

    try:

        temp = x.find_element_by_xpath(".//div[@class='_5wj-']")
        status = temp.text

        #status = x.find_element_by_xpath(".//div[@class='_5wj-']").text
        try:
            status = status + temp.find_element_by_xpath(".//span[@class='text_exposed_show']").get_attribute(
                'textContent')

            status = seeMoreRem(status)


            linkes = o
            deep = linkes.find_element_by_xpath(".//div[@class='text_exposed_root']")
            deepLinks = deep.find_elements_by_tag_name("a")

            # gereftan link post ha
            results = [p.get_attribute('href') for p in deepLinks]
            results = [create_original_link(x) for x in results]

            link = results
            # tasfieh kardan link az Hastag!
            #main_links = [line for line in results if '/arta.moaser.9/posts/' in line]
            #
            # try:
            #     link = results[0]
            # except:
            #     link = ""
            #     pass


        except:
            pass


    except:
        try:
            status = x.find_element_by_xpath(".//div[@class='userContent']").text
        except:
            pass



    return status,link


def get_div_links(x, tag):
    try:
        temp = x.find_element_by_xpath(".//div[@class='_3x-2']")
        return temp.find_element_by_tag_name(tag)
    except:
        return ""


def get_title_links(title):
    l = title.find_elements_by_tag_name('a')
    return l[-1].text, l[-1].get_attribute('href')


def get_title(x):
    title = ""
    try:
        title = x.find_element_by_xpath(".//span[@class='fwb fcg']")
    except:
        try:
            title = x.find_element_by_xpath(".//span[@class='fcg']")
        except:
            try:
                title = x.find_element_by_xpath(".//span[@class='fwn fcg']")
            except:
                pass
    finally:
        return title


def get_time(x):
    time = ""
    try:
        time = x.find_element_by_tag_name('abbr').get_attribute('title')
        time = str("%02d" % int(time.split(", ")[1].split()[1]), ) + "-" + str(
            ("%02d" % (int((list(calendar.month_abbr).index(time.split(", ")[1].split()[0][:3]))),))) + "-" + \
               time.split()[3] + " " + str("%02d" % int(time.split()[5].split(":")[0])) + ":" + str(
            time.split()[5].split(":")[1])
    except:
        pass

    finally:
        return time


def extract_and_write_posts(elements,bot_name,username):
    try:
        #f = open(filename, "w", newline='\r\n')
        #f.writelines(' TIME || TYPE  || TITLE || STATUS  ||   LINKS(Shared Posts/Shared Links etc) ' + '\n' + '\n')

        for x in elements:
            try:
                # print ('element:\n')
                # print (x)
                video_link = " "
                title = " "
                status = " "
                link = ""
                img = " "
                time = " "

                # time
                time = get_time(x)

                # title
                title = get_title(x)
                if title.text.find("shared a memory") != -1:
                    x = x.find_element_by_xpath(".//div[@class='_1dwg _1w_m']")
                    title = get_title(x)

                status,PostLink = get_status(x)
                if title.text == driver.find_element_by_id("fb-timeline-cover-name").text:
                    if status == '':
                        temp = get_div_links(x, "img")
                        if temp == '':  # no image tag which means . it is not a life event
                            link = get_div_links(x, "a").get_attribute('href')
                            type = "status update without text"
                        else:
                            type = 'life event'
                            link = get_div_links(x, "a").get_attribute('href')
                            status = get_div_links(x, "a").text
                    else:
                        type = "status update"
                        if get_div_links(x, "a") != '':
                            link = get_div_links(x, "a").get_attribute('href')

                elif title.text.find(" shared ") != -1:

                    x1, link = get_title_links(title)
                    type = "shared " + x1

                elif title.text.find(" at ") != -1 or title.text.find(" in ") != -1:
                    if title.text.find(" at ") != -1:
                        x1, link = get_title_links(title)
                        type = "check in"
                    elif title.text.find(" in ") != 1:
                        status = get_div_links(x, "a").text

                elif title.text.find(" added ") != -1 and title.text.find("photo") != -1:
                    type = "added photo"
                    link = get_div_links(x, "a").get_attribute('href')
                    img_urls = get_facebook_images_url(link)
                    pics = []
                    try:
                        if len(img_urls) > 0:
                            for imgs in img_urls:
                                b_image = picToBinary(url=imgs)
                                img_opt = image_optimizer(img=b_image)
                                pics.append(gridfs_insert_db(img=img_opt, file_name=str(username)))
                    except Exception as e:
                        print (e)
                        pics=[]


                elif title.text.find(" added ") != -1 and title.text.find("video") != -1:
                    type = "added video"
                    link = get_div_links(x, "a").get_attribute('href')
                    img_urls = get_facebook_images_url(link)
                    videos=[]
                    try:
                        if len(img_urls) > 0:
                            for imgs in img_urls:
                                b_vide = picToBinary(url=imgs)
                                #img_opt = image_optimizer(img=b_image)
                                videos.append(gridfs_insert_db(img=b_vide, file_name=str(username)))
                    except Exception as e:
                        print (e)
                        videos=[]

                else:
                    type = "others"

                if not isinstance(title, str):
                    title = title.text

                status = status.replace("\n", " ")
                title = title.replace("\n", " ")

                try:
                    try:
                        status_lanq = lanqdet(status)
                        status_tags = hashtaghEx(status)
                    except Execption as e:
                        print (e)
                        status_lanq = ''
                        status_tags = ''

                    data_status = {"bot_name":bot_name,
                                   "profile_id":username,
                                   "time":time,
                                   "type":type,
                                   "title":str(title),
                                   "status":str(status),
                                   "status_lanq":status_lanq,
                                   "status_tags":status_tags,
                                   "link":link,
                                   'pics':pics,
                                   'videos':videos,
                                   "Post Link:":PostLink}
                    kafkaproducer({"collections":"profile_scrap","data":data_status},topic="facebook_bot_01")
                    i = db.profile_scrap.insert_one(data_status)
                    logmaker(botName=bot_name,kind='log',description='data_status send to kafka 526')
                    #f.writelines(line)
                except:
                    print('Posts: Could not map encoded characters')
                    logmaker(botName=bot_name, kind='error', description='Posts: Could not map encoded characters 530')
            except:
                pass
        #f.close()
    except:
        print("Exception (extract_and_write_posts)", "Status =", sys.exc_info()[0])
        logmaker(botName=bot_name, kind='error', description='Exception (extract_and_write_posts) 536')


    return


# -------------------------------------------------------------

# -------------------------------------------------------------


def save_to_file(elements,status, current_section,username,bot_name):

    date = datetime.datetime.now()
    """helper function used to save links to files"""
    profile_id = []
    # status 0 = dealing with friends list
    # status 1 = dealing with photos
    # status 2 = dealing with videos
    # status 3 = dealing with about section
    # status 4 = dealing with posts

    try:

        f = None  # file pointer

        if status != 4:
            pass
            #f = open(name, 'w', encoding='utf-8', newline='\r\n')

        results = []
        img_names = []

        # dealing with Friends
        if status == 0:

            results = [x.get_attribute('href') for x in elements]
            results = [create_original_link(x) for x in results]

            try:
                for i in results:
                    data={"bot_name":bot_name,"profile_id": i, "crawlStatus": False,"date":date}
                    kafkaproducer({"collections":"profile_list","data":data},topic="facebook_bot_01")
                    i2 = db.profile_list.insert_one(data)
                    logmaker(botName=bot_name, kind='log', description='profile_list send to kafka 576')
                    profile_id.append(i.split('/')[-1])

            except Exception as e:
                print(e)
                print("error")
                logmaker(botName=bot_name, kind='error', description='profile_list send to kafka failed 584')
                pass
            if len(profile_id) > 0:
                try:
                    fri_list = []
                    for f in profile_id:
                      if sep in f:
                         sep = '?'
                         rest = f.split(sep, 1)[0]
                         fri = re.sub(sep, '', rest)
                         fri_list.append(fri)
                      else:
                          fri_list.append(f)
                except Exception as e:
                    print(e)


                data = {"bot_name": bot_name, "profile_id": username, "friends": fri_list, "date": date}
                print(data)
                i = db.facebook_friends.insert(data)
                kafkaproducer({"collections": "facebook_friends", "data": data}, topic="facebook_bot_01")
                logmaker(botName=bot_name, kind='log', description='facebook_friends send to kafka 586')
                friends_list = []
                for f in friends_list:
                    profile = f.split('/')[-1]
                    if (profile.isnumeric()):
                        friends_list.append(profile)
                    friends_list.append(profile)
                print(friends_list)
                try:
                    if fri_list > 0:
                        neo4j_insert(username=username, friends=friends_list, bot_name=bot_name)

                except Exception as e:
	                print(e)




            #mongodb

            try:
                if download_friends_photos:

                    if friends_small_size:
                        img_links = [x.find_element_by_css_selector('img').get_attribute('src') for x in elements]
                    else:
                        links = []
                        for friend in results:
                            driver.get(friend)
                            WebDriverWait(driver, 10).until(
                                EC.presence_of_element_located((By.CLASS_NAME, "profilePicThumb")))
                            l = driver.find_element_by_class_name("profilePicThumb").get_attribute('href')
                            links.append(l)

                        for i in range(len(links)):
                            if links[i].find('picture/view') != -1:
                                links[i] = "None"
                        img_links = get_facebook_images_url(links)


                    folder_names = ["Friend's Photos", "Following's Photos", "Follower's Photos", "Work Friends Photos",
                                    "College Friends Photos", "Current City Friends Photos", "Hometown Friends Photos"]
                    #print("Downloading " + folder_names[current_section])

                    #print(img_links)
                    if len(img_links) > 0:
                        data = {"bot_name": bot_name, "img_links": img_links, "Sections": folder_names[current_section],
                                "results": results, "date": date}
                        kafkaproducer({"collections": "facebook_img_links", "data": data}, topic="facebook_bot_01")

                    #img_names = image_downloader(img_links, folder_names[current_section],results)
            except:
                print("Exception (Images)", str(status), "Status =", current_section, sys.exc_info()[0])
                logmaker(botName=bot_name, kind='error', description="Exception (Images) 626")

        # dealing with Photos
        elif status == 1:
            results = [x.get_attribute('href') for x in elements]
            results.pop(0)

            try:
                if download_uploaded_photos:
                    if photos_small_size:
                        background_img_links = driver.find_elements_by_xpath("//*[contains(@id, 'pic_')]/div/i")
                        background_img_links = [x.get_attribute('style') for x in background_img_links]
                        background_img_links = [((x.split('(')[1]).split(')')[0]).strip('"') for x in
                                                background_img_links]
                    else:
                        background_img_links = get_facebook_images_url(results)

                    folder_names = ["Uploaded Photos", "Tagged Photos"]
                    #print("Downloading " + folder_names[current_section])


                    data = {"bot_name":bot_name,"background_img_links": background_img_links, "file name": folder_names[current_section],"date":date}
                    kafkaproducer({"collections": "facebook_img_links", "data": data}, topic="facebook_bot_01")
                    logmaker(botName=bot_name, kind='log', description="facebook_img_links send to kafka 650")
                    #img_names = image_downloader(background_img_links, folder_names[current_section])

            except:
                print("Exception (Images)", str(status), "Status =", current_section, sys.exc_info()[0])
                logmaker(botName=bot_name, kind='error', description="Exception (Images) 655")


        # dealing with Videos
        elif status == 2:
            results = elements[0].find_elements_by_css_selector('li')
            results = [x.find_element_by_css_selector('a').get_attribute('href') for x in results]

            try:
                if results[0][0] == '/':
                    results = [r.pop(0) for r in results]
                    #results = [("https://en-gb.facebook.com/" + x) for x in results]
                    # print("result-inja")
                    print(results)
            except:
                pass

        # dealing with About Section
        elif status == 3:
            results = elements[0].text
            results = removeStr(results)
            type = re.findall('([A-Z]+(?:(?!\s?[A-Z][a-z])\s?[A-Z])+)', results)


            if "Birthday" in results:
                before_keyword, keyword, after_keyword = results.partition("Birthday")
                Birthday = {"bot_name":bot_name,"profile_id":username,"Birthday":after_keyword,"date":date}
                kafkaproducer({"collections": "profile_scrap", "data": Birthday}, topic="facebook_bot_01")
                i = db.profile_scrap.insert_one(Birthday)
                logmaker(botName=bot_name, kind='log', description='profile_scrap send to kafka 676')

            if "Phones" in results:
                unique_word_a = 'Phones'
                unique_word_b = 'Birthday'
                s = results
                phoneNumber = s[s.find(unique_word_a) + len(unique_word_a):s.find(unique_word_b)].strip()
                Phones = {"bot_name":bot_name,"profile_id":username,"Phones":phoneNumber,"date":date}
                kafkaproducer({"collections": "profile_scrap", "data": Phones}, topic="facebook_bot_01")
                i = db.profile_scrap.insert_one(Phones)
                logmaker(botName=bot_name, kind='log', description='profile_scrap send to kafka 686')


            if type == []:
                if "workplace" in results:
                    type = ['workplace','school/university','current city',"..."]

            data = {"bot_name":bot_name,"profile_id":username,"Abouts": type,"data":results,"date":date}
            kafkaproducer({"collections": "profile_scrap", "data": data}, topic="facebook_bot_01")
            i = db.profile_scrap.insert_one(data)
            logmaker(botName=bot_name, kind='log', description='profile_scrap send to kafka 696')


        # dealing with Posts
        elif status == 4:
            extract_and_write_posts(elements=elements,username=username,bot_name=bot_name)
            return

    except:
        print("Exception (save_to_file)", "Status =", str(status), sys.exc_info()[0])
        logmaker(botName=bot_name, kind='error', description="Exception (save_to_file) 730")

    return


# ----------------------------------------------------------------------------

# -----------------------------------------------------------------------------

def scrap_data(id, scan_list, section, elements_path, save_status, file_names,bot_name):
    """Given some parameters, this function can scrap friends/photos/videos/about/posts(statuses) of a profile"""
    username = id.split('/')[-1]
    page = []

    if save_status == 4:
        page.append(id)

    for i in range(len(section)):
        page.append(id + section[i])
    for i in range(len(scan_list)):

        try:
            driver.get(page[i])

            if (save_status == 0) or (save_status == 1) or (
                    save_status == 2):  # Only run this for friends, photos and videos

                # the bar which contains all the sections
                sections_bar = driver.find_element_by_xpath("//*[@class='_3cz'][1]/div[2]/div[1]")

                if sections_bar.text.find(scan_list[i]) == -1:
                    continue

            if save_status != 3:
                scroll()


            data = driver.find_elements_by_xpath(elements_path[i])

            name = file_names[i]
            elements = data
            save_status = int(save_status)
            current_section = int(i)
            username = str(username)
            bot_name = str(bot_name)


            save_to_file(elements= data,status=save_status,current_section= current_section,username=username,bot_name=bot_name)

        except Exception as e:
            print(774)
            print(e)
            #print("Exception (scrap_data)", str(i), "Status =", str(save_status), sys.exc_info()[0])
            logmaker(botName=bot_name, kind='error', description="Exception (scrap_data) 774")


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def create_original_link(url):
    if url.find(".php") != -1:
        original_link = "https://en-gb.facebook.com/" + ((url.split("="))[1])

        if original_link.find("&") != -1:
            original_link = original_link.split("&")[0]

    elif url.find("fnr_t") != -1:
        original_link = "https://en-gb.facebook.com/" + ((url.split("/"))[-1].split("?")[0])
    elif url.find("_tab") != -1:
        original_link = "https://en-gb.facebook.com/" + (url.split("?")[0]).split("/")[-1]
    else:
        original_link = url

    return original_link


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def scrap_profile(ids,bot_name,a_u):

    while True:

        if a_u == 1:  # auto
            profile_list_count = db.profile_list.find({"bot_name": bot_name, "crawlStatus": False}).count()
            if profile_list_count > 0:
                profile_list = db.profile_list.find({"bot_name": bot_name, "crawlStatus": False})
                for i in profile_list:
                    #print(i['profile_id'])
                    ids.append(i['profile_id'])

        if len(ids) == 0:
            break

        # execute for all profiles given in input.txt file
        for id in ids:
            driver.get(id)
            url = driver.current_url
            id = create_original_link(url)

            print("\nScraping:", id)

            # ----------------------------------------------------------------------------
            print("----------------------------------------")
            print("Friends..")
            # setting parameters for scrap_data() to scrap friends
            scan_list = ["All", "Following", "Followers", "Work", "College", "Current City", "Hometown"]
            section = ["/friends", "/following", "/followers", "/friends_work", "/friends_college",
                       "/friends_current_city",
                       "/friends_hometown"]
            elements_path = ["//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                             "//*[contains(@class,'_3i9')][1]/div/div/ul/li[1]/div[2]/div/div/div/div/div[2]/ul/li/div/a",
                             "//*[contains(@class,'fbProfileBrowserListItem')]/div/a",
                             "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                             "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                             "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                             "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a"]
            file_names = ["All Friends.txt", "Following.txt", "Followers.txt", "Work Friends.txt",
                          "College Friends.txt",
                          "Current City Friends.txt", "Hometown Friends.txt"]
            save_status = 0

            scrap_data(id, scan_list, section, elements_path, save_status, file_names, bot_name=bot_name)
            print("Friends Done")
            # # ----------------------------------------------------------------------------
            #
            print("----------------------------------------")
            print("Photos..")
            print("Scraping Links..")
            # setting parameters for scrap_data() to scrap photos
            scan_list = ["'s Photos", "Photos of"]
            section = ["/photos_all", "/photos_of"]
            elements_path = ["//*[contains(@id, 'pic_')]"] * 2
            file_names = ["Uploaded Photos.txt", "Tagged Photos.txt"]
            save_status = 1

            scrap_data(id, scan_list, section, elements_path, save_status, file_names, bot_name=bot_name)
            print("Photos Done")

            print("----------------------------------------")
            print("About:")
            # setting parameters for scrap_data() to scrap the about section
            scan_list = [None] * 7
            section = ["/about?section=overview", "/about?section=education", "/about?section=living",
                       "/about?section=contact-info", "/about?section=relationship", "/about?section=bio",
                       "/about?section=year-overviews"]
            elements_path = ["//*[contains(@id, 'pagelet_timeline_app_collection_')]/ul/li/div/div[2]/div/div"] * 7
            file_names = ["Overview.txt", "Work and Education.txt", "Places Lived.txt", "Contact and Basic Info.txt",
                          "Family and Relationships.txt", "Details About.txt", "Life Events.txt"]
            save_status = 3

            scrap_data(id, scan_list, section, elements_path, save_status, file_names, bot_name=bot_name)
            print("About Section Done")

            # ----------------------------------------------------------------------------
            print("----------------------------------------")
            print("Posts:")
            # setting parameters for scrap_data() to scrap posts
            scan_list = [None]
            section = []
            elements_path = ['//div[@class="_5pcb _4b0l _2q8l"]']
            file_names = ["Posts.txt"]
            save_status = 4
            scrap_data(id, scan_list, section, elements_path, save_status, file_names, bot_name=bot_name)
            print("Posts(Statuses) Done")
            print("----------------------------------------")
            # ----------------------------------------------------------------------------
            date = datetime.datetime.now()

            try:
                u = db.profile_list.update({"profile_id": id, "bot_name": bot_name},
                                           {"$set": {"crawlStatus": True, "date": date}}, True, True)
            except Exception as e:
                print(e)

            logmaker(botName=bot_name, kind='log', description='profile_list mongodb update')
            try:
                ids.remove(id)
            except Exception as e:
                print(e)

    return


# -----------------------------------------------------------------------------
def update_bot(bot_name,profile_list,period,aut_man):
    try:
        bot_name_find = db.bot_names.find({"bot_name": bot_name}).count()
        if bot_name_find == 0:
            return False
        else:
            update = db.insta_bot_names.update_one({'bot_name': bot_name}, {
                "$set": {"profile_list": profile_list, "period": period, "aut_man": aut_man}}, True, True)
            return True
    except Exception as e:
        logmaker(botName=bot_name,kind='error',description='update func - error:%s - 675' % str(e))
        return str(e)

# -----------------------------------------------------------------------------

def login(bot_name,email, password):
    """ Logging into our own profile """

    global driver

    options = Options()

    #  Code to disable notifications pop up of Chrome Browser
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-infobars")
    options.add_argument("--mute-audio")
    # options.add_argument("--headless")

    i = False

    try:
        platform_ = platform.system().lower()
        if platform_ in ['linux', 'darwin']:
            driver = webdriver.Chrome(executable_path=chromedrive_path, options=options)
        else:
            driver = webdriver.Chrome(executable_path="./chromedriver.exe", options=options)
    except:
        print("chrome driver not working correctly"
              "\nYour OS: {}".format(platform_)
              )
        logmaker(botName=bot_name, kind='error', description="chrome driver not working correctly 967")
        exit()

    driver.get("https://en-gb.facebook.com")
    driver.maximize_window()


    try:
        # filling the form
        print ("Start login user as %s" % email)
        driver.find_element_by_name('email').send_keys(email)
        driver.find_element_by_name('pass').send_keys(password)

        # clicking on login button
        driver.find_element_by_id('loginbutton').click()

    except Exception as e:
        print("There's some error in log in.")
        print(sys.exc_info()[0])
        logmaker(botName=bot_name, kind='error', description="There's some error in log in. 985")
        exit()


# -----------------------------------------------------------------------------

def start_resume(bot_name,aut_man,period,profile_list):
    date = datetime.datetime.now()

    bot_name_find = db.bot_names.find({"bot_name": bot_name}).count()
    if bot_name_find == 0:
        bot_name_insert = db.insta_bot_names.insert_one({'bot_name': bot_name,"profile_list":profile_list,"period":period,"aut_man":aut_man, 'first_d': date, 'last_d': date, 'status': False, 'counter': 0})
        c = 0
        return 'start', c ,aut_man,period,profile_list

    if bot_name_find > 0:
        bot_name_find = db.insta_bot_names.find({'bot_name': bot_name})

        for i in bot_name_find:
            status = i['status']
            counter = i['counter']
            profile_list=i['profile_list']
            period=i['period']
            aut_man=i['aut_man']
            c = counter
            if status == True:
                update = db.insta_bot_names.update_one({'bot_name': bot_name}, {"$set": {"status": False, "profile_list":profile_list,"period":period,"aut_man":aut_man,'last_d': date}},True, True)
                c = counter
                return 'start', c,aut_man,period,profile_list
            else:
                return 'resume', c,aut_man,period,profile_list

# -----------------------------------------------------------------------------

def main(username,password,bot_name,aut_man,period='n',profile_list = []):
    date = datetime.datetime.now()

    #mkdir botname
    mk_path(BotName=bot_name)آ

    email = username
    password = password

    login(bot_name=bot_name,email=email,password=password)



    if period != 'n':
        while True:
            status, c, aut_man, period, profile_list = start_resume(bot_name=bot_name, aut_man=aut_man, period=period,
                                                                    profile_list=profile_list)
            if len(profile_list) == 0:
                profile_list= ['https://www.facebook.com/zuck']
            try:
                scrap_profile(profile_list, bot_name, a_u=aut_man)
            except Exception as e:
                print(e)
                return e

            profile_list = {'profile_list':profile_list,'bot_name':bot_name,"period":period,"date":date,"next_period":period_date}
            print(profile_list)
            i = db.profile_list_scraped.insert_one({'profile_list':profile_list,'bot_name':bot_name,"period":period,"date":date,"next_period":period_date})
            kafkaproducer({"collections": "profile_list_scraped", "data": profile_list}, topic="facebook_bot_01")
            logmaker(botName=bot_name, kind='log', description='profile_list send to kafka 1004')
            period_date = periodCal(kind=period)
            t = bot_sleep_time(period_date)
            time.sleep(t)
    else:
        status, c, aut_man, period, profile_list = start_resume(bot_name=bot_name, aut_man=aut_man, period=period,
                                                                profile_list=profile_list)
        if len(profile_list) == 0:
            profile_list = ['https://www.facebook.com/zuck']
        try:
            scrap_profile(profile_list, bot_name, a_u=aut_man)
        except Exception as e:
            print(e)
            return e

        return True


    driver.close()





# -------------------------------------------------------------
# -------------------------------------------------------------
# -------------------------------------------------------------

if __name__ == '__main__':
    # get things rolling
    main(username=989128439547,password='DaryaMajd',bot_name='FBbot',aut_man=1,profile_list = ['https://www.facebook.com/arta.moaser.9'])





