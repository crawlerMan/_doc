def neo4j_insert(username, user_id, follower_list, following_List):
    if (matcher.match("Users", user_id=user_id).first() == None):
        try:
            owner = Node("Users", username=username, user_id=user_id)
            gr.create(owner)
        except Exception as e:
            print (e)
    else:
        try:
            owner = matcher.match("Users", user_id=user_id).first()
        except Exception as e:
            print (e)

    for ff_er in follower_list:
        if (matcher.match("Users", user_id=ff_er).first() == None):
            try:
                a = Node("Users", user_id=user_id)
                gr.create(a)
            except Exception as e:
                print (e)

        else:
            try:
                a = matcher.match("Users", user_id=ff_er).first()
            except Exception as e:
                print (e)
        try:
            a_owner = Relationship(a, "FOLLOW", owner)
            gr.create(a_owner)
        except Exception as e:
            print (e)


    for ff_in in following_List:
        if (matcher.match("Users", user_id=ff_in).first() == None):
            try:
                a = Node("Users", user_id=user_id)
                gr.create(a)
            except Exception as e:
                print (e)
            else:
                try:
                    a = matcher.match("Users", user_id=ff_in).first()
                except Exception as e:
                    print (e)
        try:
            owner_a = Relationship(owner, "FOLLOW", a)
            gr.create(owner_a)
            print(owner_a)
        except Exception as e:
            print (e)

