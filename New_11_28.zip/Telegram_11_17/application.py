import os
import time
from flask import Flask, request,jsonify
from celery import Celery
from Telegram_scraper import authentication,main,update_bot
from celery.exceptions import Ignore
import datetime
from celery.task.control import revoke

#-------------MongoDB Config-------------#
from pymongo import MongoClient
mongo_client = MongoClient('10.0.1.178:47017')
#mongo_client = MongoClient('localhost:27017')
db = mongo_client.telegram
#--------------*****----------------------#




app = Flask(__name__)

# Celery configuration - rabbitmq
app.config['CELERY_BROKER_URL'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/teleg_bot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/teleg_bot'

# app.config['CELERY_BROKER_URL'] = 'amqp://instaB:HNA123@localhost:5672/instabot'
# app.config['CELERY_RESULT_BACKEND'] = 'amqp://instaB:HNA123@localhost:5672/instabot'


# Celery configuration - mongodb
# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)


@celery.task(bind=True)
def telegram_bot_task(self,*args,**kwargs):
    api_id  = args[0]
    api_hash=args[1]
    phone   =args[2]
    BotName =args[3]
    period  =args[4]
    search  =args[5]
    grLink  =args[6]
    chLink  =args[7]
    limit_g =args[8]
    limit_c = args[9]

    date = str(datetime.datetime.now())
    message = BotName + ' ' + "Started at %s" % date
    self.update_state(state='STARTED', meta={'message': message})
    time.sleep(1)
    message = BotName + ' ' + "is now Runnig"
    self.update_state(state='PROGRESS', meta={'message': message})
    time.sleep(1)
    x = main(bot_name=BotName,api_id=api_id,api_hash=api_hash,phone=phone,search=search,period=period,grLink=grLink,chLink=chLink,limit_g=limit_g,limit_c=limit_c)
    if x == 5:
        self.update_state(state='SUCCESS', meta={'message': 'Crawl was finished'})
        return {'status': 'Task completed!'}
    elif x == 4:
        self.update_state(state='FAILURE', meta={'message': 'Both grLink and chLink is empty!'})
        return Ignore()
    else:
        self.update_state(state='FAILURE', meta={'message': x})
        return Ignore()

    self.update_state(state='PROGRESS')
    time.sleep(1)
    return {'status': 'Task completed!'}



@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()
    api_id   = data['api_id']
    api_hash = data['api_hash']
    phone    = data['phone']
    BotName  = data['bot_name']
    period   = data['period']
    search   = data['search']
    aut_code = data['aut_code']
    grLink   = data['grLink']
    chLink   = data['chLink']
    limit_g  = data['limit_g']
    limit_c = data['limit_c']

    mongo_data = {"api_id": api_id,"api_hash": api_hash,"phone": phone,"bot_name": BotName,
     "period": period,"search": search,"aut_code": aut_code,"grLink":grLink,"chLink": chLink,"limit_g":limit_g,"limit_c":limit_c}


    #i = db.telegram_bot.insert_one(mongo_data)

    x = authentication(api_id=api_id, api_hash=api_hash, phone=phone, aut_code=aut_code,bot_name=BotName)
    if x == 0:
        return jsonify({"message": "plz send aut code"}), 401
    # if x == 3:
    #     return jsonify({"message": "aut code is not correct!"}), 401
    elif x == 1:
        print("connect succesful")

        task = telegram_bot_task.apply_async(args=[api_id, api_hash, phone, BotName,
                                           period, search, grLink, chLink,limit_g,limit_c])
        return jsonify({"task_id":task.id}), 202
    else:
        x = str(x)
        return jsonify({"message": x}), 401

    x = str(x)
    return jsonify({"message": x}), 401




@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = telegram_bot_task.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': str(task.info)
        }
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)



# @app.route('/revoke/<task_id>')
# def revokes(task_id):
#     x = revoke(task_id,Terminate = True, signal = 'SIGKILL')
#     print(x)
#
#     return jsonify({"message":srt(x)})



def update():
    data = request.get_json()

    bot_name = data['bot_name']
    grlink   = data['grlink']
    chlink   = data['chlink']
    limit_g  = data['limit_g']
    limit_c  = data['limit_c']
    period   = data['period']

    u = update_bot(bot_name=bot_name,grlink=grlink,chlink=chlink,limit_g=limit_g,limit_c=limit_c,period=period)

    if u == True:
        return jsonify({"message": "bot arguments is update"}), 202

    elif u == False:
        return jsonify({"message": "bot update was failed"}), 409

    else:
        return jsonify({"message": str(u)}), 409



@app.route('/addaccount/<variable>/', methods=['GET', 'POST'])
def addAccount(variable):
    if request.method == 'POST':

        data = request.get_json()
        api_id = data['api_id']
        api_hash = data['api_hash']
        phone = data['phone']
        name = data['name']
        username = data['username']

        if variable == 'add':
            try:
                user_insert = db.users.insert_one({"username": username, "api_id": api_id, "api_hash": api_hash,"phone":phone,"name":name})
            except Exception as e:
                return jsonify({"message": str(e)}), 400
            return jsonify({"message": "user added!"}), 202
        else:
            try:
                update = db.insta_bot_names.update_one({"phone":phone},{
                    "$set": {"username": username, "api_id": api_id, "api_hash": api_hash,"name":name}}, True, True)
                return jsonify({"message": "user was updated!"}), 202
            except Exception as e:
                return jsonify({"message": str(e)}), 400

    else:
        try:
            if variable == 'all':
                find_username = db.users.find()
                j = 0
                users = []
                for i in find_username:
                    users.append({"id": j, "username": i['username'], "api_id": i['api_id'],"api_hash":i['api_hash'],"phone":i["phone"] ,"name": i["name"]})
                    j = j + 1
            else:
                find_username = db.users.find({"username": variable})
                j = 0
                users = []
                for i in find_username:
                    users.append({"id": j, "username": i['username'], "api_id": i['api_id'],"api_hash":i['api_hash'],"phone":i["phone"] ,"name": i["name"]})
                    j = j + 1

        except Exception as e:
            return jsonify({"message": str(e)}), 400

        return jsonify({"meassge":users}),202




@app.route('/query/<variable>/', methods=['GET', 'POST'])
def query(variable):

    if request.method == 'POST':



        if variable == 'user':
            data = request.get_json()
            users = data['username']
            try:
                j = 0
                data = []
                for username in users:
                    find = db.telegram_group_people.find({"username": username})
                    c = 0
                    user_data = []
                    for i in find:
                        user_data.append({"id":c,"user":i})
                        c = c + 1
                    data.append({"id":j,"user":username,"data":user_data})
                    j = j + 1

            except Exception as e:
                return jsonify({"message": str(e)}), 400
            return jsonify({"message": data}), 202
        else:
            data = request.get_json()
            func = data['func']#group or channel
            words = data['words']  # group or channel

            try:
                if func == ch:
                    data = []
                    j = 0
                    for word in words:
                        find = db.channel_posts.find({"$text": {"$search": word}})
                        c = 0
                        word_data = []
                        for i in find:
                            word_data.append({"id": c, "data": i})
                            c = c + 1
                        data.append({"id": j, "word": word, "data": word_data})
                        j = j + 1

                    return jsonify({"message": data}), 202
                else:
                    data = []
                    j = 0
                    for word in words:
                        find = db.groups_message_info.find({"$text": {"$search": word}})
                        c = 0
                        word_data = []
                        for i in find:
                            word_data.append({"id": c, "data": i})
                            c = c + 1
                        data.append({"id": j, "word": word, "data": word_data})
                        j = j + 1

                    return jsonify({"message": data}), 202


            except Exception as e:
                return jsonify({"message": str(e)}), 400

    else:
        try:
            if variable == 'alluser':
                profile_count = db.telegram_group_people.distinct("user_id").length
                data = {"data":int(profile_count)}

            elif variable == "allgrmedia":
                media_count = db.groups_message_info.distinct("message").length
                data = {"data": int(media_count)}

            elif variable == "allchmedia":
                media_count = db.channel_posts.distinct("message").length
                data = {"data": int(media_count)}


        except Exception as e:
            return jsonify({"message": str(e)}), 400

        return jsonify({"meassge":data}),202



if __name__ == '__main__':
    app.run('0.0.0.0',port=5000,debug=True)
