from instabot import Bot
import time
from datetime import datetime, timedelta
from textblob import TextBlob
import re
import emoji
from bson.binary import Binary
import requests
import os
from collections import Counter
from persiantools.jdatetime import JalaliDateTime
import datetime, pytz
import jsonify
from Functions import removeStr,remove_emoji,lanqdet,spliteKeyWord,hashtaghEx


#global list
sleep_period_list=[]

#-------------MongoDB Config-------------#

from pymongo import MongoClient
#client = MongoClient('127.0.0.1:27017')
client = MongoClient('localhost:27017')
db = client.InstagramCrawl

#--------------*****----------------------#


#-------------Neo4j Config-------------#
from py2neo import Node,Database, Graph,Relationship,NodeMatcher

gr = Graph(password='HNADZBE')
matcher = NodeMatcher(gr)
#-------------Neo4j Config End -------------#




#--------------Log maker function----------------------#

def logmaker(bot="insta",botName='default',kind=" ",description=" "):
	date = JalaliDateTime.now(pytz.timezone("Asia/Tehran")).strftime("%c")
	title = "Date & Time:              " + "\t" + "Bot Name:" + "\t   " + "Kind:" + "   \t" + "Description:" + "\t" + "\n"
	log = str(date) + "\t    " + str(botName) + "    \t     " + str(kind) + "\t     " + str(description) + "\t" + "\n"

	if os.path.exists("%s_%s_Log.txt" % (botName, bot)):
		logFile = open("%s_%s_Log.txt" % (botName, bot), "a+")
		logFile.write(log)
		logFile.close()

	else:
		with open("%s_%s_Log.txt" % (botName, bot), "w") as NewlogFile:
			NewlogFile.write(title)
			NewlogFile.write(log)
			NewlogFile.close()



#--------------Log maker function End ----------------------#

#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
    date = datetime.datetime.now()

    if kind == 'y':
        periodD = date + timedelta(days=365)

    if kind == 'm':
        periodD = date + timedelta(days=30)

    if kind == 'w':
        periodD = date + timedelta(days=7)

    if kind == 'd':
        periodD = date + timedelta(days=1)

    if kind == 'n':
        periodD = date

    return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#


#-------------Kafka Config----------------#

from confluent_kafka import Producer
import json

def kafkaproducer(jsn,topic,botName='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    print(jsn)

def kafkaproducerN(jsn,topic,botName='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    data = str(jsn)

    def delivery_report(err, msg):
        """ Called once for each message produced to indicate delivery result.
            Triggered by poll() or flush(). """
        if err is not None:
            Kafkaerror='Message delivery failed: {}'.format(err)
            print(Kafkaerror)
            logmaker(bot="insta", kind="error",botName=botName, description="kafka Message delivery failed - topic: %s " % topic)
            logmaker(bot="insta", kind="error",botName=botName, description= Kafkaerror)

        else:
            print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))
    try:
        p = Producer({'bootstrap.servers': brokers})

    except:
        print("plz Check Kafka connections...")
        logmaker(bot="insta", kind="error", botName=botName,description="kafka connections error ")
        time.sleep(10)
        pass

    try:
        # Trigger any available delivery report callbacks from previous produce() calls
        p.poll(0)
        p.produce(topic, data.encode('utf-8'), callback=delivery_report)

        p.flush()

    except:
        print("somethings wet wrong in kafka produce")
        logmaker(bot="insta", kind="error", botName=botName,description="somethings wet wrong in kafka produce - topic: %s " % topic)

#--------------*****----------------------#

#--------------root path maker----------------------#


def mk_path(BotName='default'):
    bot_name_path = str(BotName)
    root_path = os.getcwd()
    root_path = root_path + '/instagram_bot'
    new_root_path = root_path + '/' + bot_name_path

    try:
        if os.path.exists(new_root_path):
            os.chdir(new_root_path)
        else:
            if os.path.exists(root_path):
                os.mkdir(new_root_path)
            else:
                os.mkdir(root_path)
                os.chdir(root_path)

                os.mkdir(new_root_path)
                os.chdir(new_root_path)

        print("Successfully open the directory %s " % new_root_path)
        logmaker(bot="insta", kind="log", botName=BotName,
                 description="Successfully created the directory %s " % new_root_path)

        return new_root_path

    except OSError:
        print("Creation of the directory %s failed" % new_root_path)
        logmaker(bot="insta", kind="error", botName=BotName,
                 description="Opening of the directory %s failed" % new_root_path)
#--------------root path maker end----------------------#







# def picToBinary(url):
#     Picture_request = requests.get(url)
#     if Picture_request.status_code == 200:
#         return Picture_request.content



bot = Bot()



#-------------Neo4j Insert -------------#

def neo4j_insert(username,user_id,follower_list,following_List):

	try:
		if (matcher.match("Users", user_id=user_id).first() == None):
			owner = Node("Users", username=username, user_id=user_id)
			gr.create(owner)
		else:
			owner = matcher.match("Users", user_id=user_id).first()
	except:
		print ("somethings worong in insert owner in Neo4j")


	try:
		counter = 0
		counter = int(counter)

		for ff_er in follower_list:

			if (matcher.match("Users", user_id=ff_er).first() == None):
				try:
					findc = db.instagram_users_info.find({"user_id": ff_er}).count()
					if findc > 0:
						find = db.instagram_users_info.find({"user_id": ff_er})
						for i in find:
							username_ff_er = ['username']
							break
				except:
					print("somethings was wrong in mongodb connect!")

				else:
					try:
						username_ff_er = bot.get_username_from_user_id(user_id=ff_er)
						counter = int(counter) + 1
						if counter > 30:
							time.sleep(300)
							counter = 0
					except:
						print('somethings was wrongs in instagram bot')



				a = Node("Users", username=str(username_ff_er),user_id=user_id)
				gr.create(a)
			else:
				a = matcher.match("Users", user_id=ff_er).first()

			a_owner = Relationship(a, "FOLLOW", owner)
			gr.create(a_owner)
			print(a_owner)
	except:
		print ("somethings worong in insert followers in Neo4j")

	try:
		for ff_in in following_List:

			if (matcher.match("Users", user_id=ff_in).first() == None):
				try:
					findc = db.instagram_users_info.find({"user_id": ff_in}).count()
					if findc > 0:
						find = db.instagram_users_info.find({"user_id": ff_in})
						for i in find:
							username_ff_in = ['username']
							break
				except:
					print("somethings was wrong in mongodb connect!")

				else:
					try:
						username_ff_in = bot.get_username_from_user_id(user_id=ff_in)
						counter = int(counter) + 1
						if counter > 30:
							time.sleep(300)
							counter = 0
					except:
						print('somethings was wrongs in instagram bot')

				a = Node("Users",username=str(username_ff_in), user_id=user_id)
				gr.create(a)
			else:
				a = matcher.match("Users", user_id=ff_in).first()
			owner_a = Relationship(owner, "FOLLOW", a)
			gr.create(owner_a)
			print(owner_a)

	except:
		print ("somethings worong in insert followeing in Neo4j")

#-------------Neo4j Insert-------------#




def resume(bot_name='default'):
    try:
        if os.path.exists("%s_resume.txt" %bot_name):
            f = open("%s_resume.txt" %bot_name, "r")
            if f.mode == "r":
                x = f.readlines()

                for i in range(len(x)):
                    x[i]=removeStr(x[i])

                if len(x) == 0:
                    return None

                else:
                    return x

        else:
            print("resume file not found!")
            return 0,0,0

    except:
        print("somthings wrongs in resume...!")
        logmaker(bot="insta", kind="error", description="resume user crawl error 132 ")




#image extractor from json
def imageLists(img):
    for k in img:
        imageList = []
        width = k["width"]
        height = k["height"]
        url = k["url"]
        #binary = picToBinary(url)
        imageList.append({"width": width, "height": height, "url": url})
    return imageList

def getInstagramUrlFromMediaId(media_id):
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
    shortened_id = ''

    while media_id > 0:
        remainder = media_id % 64
        # dual conversion sign gets the right ID for new posts
        media_id = (media_id - remainder) // 64;
        # remainder should be casted as an integer to avoid a type error.
        shortened_id = alphabet[int(remainder)] + shortened_id

    return 'https://instagram.com/p/' + shortened_id + '/'


def scrape(user_id,botName,status,count, dl_m=False, sleep_counters=50):
    sleep_counter = sleep_counters
    date = datetime.datetime.now()

    if status == 0:#resume

        info_username_skip_list = []
        ff_username_skip_list = []
        mediaID_skip_list = []

        instagram_users_info_skip = db.instagram_users_info.find({'botName': botName,'counter': count})
        for i in instagram_users_info_skip:
            info_username_skip_list.append(i['username'])

        instagram_user_ff_skip = db.instagram_user_ff.find({'botName': botName,'counter': count})
        for j in instagram_user_ff_skip:
            ff_username_skip_list.append(j['username'])

        instagram_users_posts_skip = db.instagram_users_posts.find({'botName': botName,'counter': count})
        for k in instagram_users_posts_skip:
            mediaID_skip_list.append(k['mediaID'])



            # userId = bot.get_user_id_from_username(username)
            username = bot.get_username_from_user_id(user_id)

            if username in instagram_users_info_skip:

                if username in ff_username_skip_list:
                    pass
                else:
                    if o["is_private"] == False:
                        followers = bot.get_user_followers(user_id=user_id)
                        following = bot.get_user_following(user_id=user_id)

                        data_ff = {'bot_name': botName, 'username': username, 'user_id': user_id,
                                   'followers': followers,
                                   'following': following, 'crawl_status': False, 'date': date, 'counter': count}
                        i = db.instagram_user_ff.insert_one(data_ff)
                        neo4j_insert(username=username, user_id=user_id, follower_list=followers, following_List=following)
            else:
                profileInfo = bot.get_user_info(user_id=user_id)

                print(profileInfo)

                o = profileInfo

                date_profile = {'botName': botName, "owner": username, "username": o["username"], "user_id": user_id,
                                "full_name": o["full_name"], "is_private": o["is_private"],
                                "follower_count": o["follower_count"], "following_count": o["following_count"],
                                "biography": o["biography"], "linke": o["external_url"],
                                "profile_pic": o["profile_pic_url"],
                                'date': date, 'counter': count}

                i = db.instagram_users_info.insert_one(date_profile)

                if username in ff_username_skip_list:
                    pass
                else:
                    if o["is_private"] == False:
                        followers = bot.get_user_followers(user_id=user_id)
                        following = bot.get_user_following(user_id=user_id)

                        data_ff = {'bot_name': botName, 'username': username, 'user_id': user_id,
                                   'followers': followers,
                                   'following': following, 'crawl_status': False, 'date': date, 'counter': count}
                        i = db.instagram_user_ff.insert_one(data_ff)
                        neo4j_insert(username=username, user_id=user_id, follower_list=followers, following_List=following)




            medias = bot.get_total_user_medias(user_id=user_id)

            for m in medias:

                if m in mediaID_skip_list:
                    pass
                else:
                    coment = []
                    coments = bot.get_media_comments(m)

                    try:
                        for c in coments:
                            lanDC = lanqdet(c["text"])
                            a = {'botName': botName, "owner": username, "mediaID": m, "user_id": c["user_id"],
                                 "username": c["user"]["username"],
                                 "full_name": c["user"]["full_name"], "text": c["text"], "coment_lanq": lanDC,
                                 'date': date,
                                 'counter': count}
                            coment.append(a)

                    except:
                        print("Somthings wrong in get comments...")
                        logmaker(bot="insta", kind="error", botName=botName, description="get comments error 325")

                    try:
                        likers = bot.get_media_likers(m)

                    except:
                        print("Somthings wrong in get likers...")
                        logmaker(bot="insta", kind="error", botName=botName, description="get likers error 332")

                    try:
                        info = bot.get_media_info(m)
                        if len(info) == 0:
                            mediaLink = getInstagramUrlFromMediaId(m)
                            data = {'botName': botName, "owner": username, "mediaID": m, "media link": mediaLink,
                                    "likers": likers,
                                    "commntes": coment, "full_crawl": False, 'date': date, 'counter': count}
                            # i = db.instagram_users_posts.insert_one(data)
                            kafkaproducer(jsn={"collections": "instagram_users_posts", "data": data}, botName=botName,
                                          topic="instagram_bot")
                            logmaker(bot="insta", kind="log", botName=botName,
                                     description="instagram_users_posts send to kafka 338 ")
                            print("owner: %s" % username)
                            ml = str(mediaLink)
                            print("media link: %s" % ml)

                            # f = open("%s_resume.txt" % botName, "a+")
                            # f.write('\n' + str(m))
                            # f.close()

                        elif len(info) > 0:
                            for i in info:
                                lande = lanqdet(i["caption"]["text"])
                                image = i["image_versions2"]["candidates"]
                                imageList = imageLists(image)
                                data = {'botName': botName, "owner": username, "mediaID": m,
                                        "caption": i["caption"]["text"],
                                        "caption_lanq": lande,
                                        "image": image, "imageList": imageList, 'image_dl': dl_m, "img_download": False,
                                        "hashtags": hashtaghEx(i["caption"]["text"]),
                                        "comment_likes_enabled": i["comment_likes_enabled"],
                                        "comment_count": i["comment_count"],
                                        "caption_is_edited": i["caption_is_edited"], "like_count": i["like_count"],
                                        "likers": likers,
                                        "commntes": coment, "full_crawl": True, 'date': date, 'counter': count}
                                # i = db.instagram_users_posts.insert_one(data)
                                kafkaproducer(jsn={"collections": "instagram_users_posts", "data": data},
                                              botName=botName,
                                              topic="instagram_bot")
                                logmaker(bot="insta", kind="log", botName=botName,
                                         description="instagram_users_posts send to kafka 361 ")
                                #
                                # f = open("%s_resume.txt" % botName, "a+")
                                # f.write('\n' + str(m))
                                # f.close()

                    except:
                        print("Somthings wrong in get infos...")
                        logmaker(bot="insta", kind="error", botName=botName, description="get infos error 375")


    else:
        # userId = bot.get_user_id_from_username(username)
        username = bot.get_username_from_user_id(user_id)
        profileInfo = bot.get_user_info(user_id=user_id)

        print(profileInfo)

        o = profileInfo

        date_profile = {'botName': botName, "owner": username, "username": o["username"], "user_id": user_id,
                        "full_name": o["full_name"], "is_private": o["is_private"],
                        "follower_count": o["follower_count"], "following_count": o["following_count"],
                        "biography": o["biography"], "linke": o["external_url"], "profile_pic": o["profile_pic_url"],
                        'date': date, 'counter': count}

        i = db.instagram_users_info.insert_one(date_profile)

        if o["is_private"] == False:
            followers = bot.get_user_followers(user_id=user_id)
            following = bot.get_user_following(user_id=user_id)

            data_ff = {'bot_name': botName, 'username': username, 'user_id': user_id, 'followers': followers,
                       'following': following, 'crawl_status': False, 'date': date, 'counter': count}
            i = db.instagram_user_ff.insert_one(data_ff)
            neo4j_insert(username=username, user_id=user_id, follower_list=followers, following_List=following)

        medias = bot.get_total_user_medias(user_id=user_id)

        for m in medias:

            coment = []
            coments = bot.get_media_comments(m)

            try:
                for c in coments:
                    lanDC = lanqdet(c["text"])
                    a = {'botName': botName, "owner": username, "mediaID": m, "user_id": c["user_id"],
                         "username": c["user"]["username"],
                         "full_name": c["user"]["full_name"], "text": c["text"], "coment_lanq": lanDC, 'date': date,
                         'counter': count}
                    coment.append(a)

            except:
                print("Somthings wrong in get comments...")
                logmaker(bot="insta", kind="error", botName=botName, description="get comments error 325")

            try:
                likers = bot.get_media_likers(m)

            except:
                print("Somthings wrong in get likers...")
                logmaker(bot="insta", kind="error", botName=botName, description="get likers error 332")

            try:
                info = bot.get_media_info(m)
                if len(info) == 0:
                    mediaLink = getInstagramUrlFromMediaId(m)
                    data = {'botName': botName, "owner": username, "mediaID": m, "media link": mediaLink,
                            "likers": likers,
                            "commntes": coment, "full_crawl": False, 'date': date, 'counter': count}
                    # i = db.instagram_users_posts.insert_one(data)
                    kafkaproducer(jsn={"collections": "instagram_users_posts", "data": data}, botName=botName,
                                  topic="instagram_bot")
                    logmaker(bot="insta", kind="log", botName=botName,
                             description="instagram_users_posts send to kafka 338 ")
                    print("owner: %s" % username)
                    ml = str(mediaLink)
                    print("media link: %s" % ml)

                    # f = open("%s_resume.txt" % botName, "a+")
                    # f.write('\n' + str(m))
                    # f.close()

                elif len(info) > 0:
                    for i in info:
                        lande = lanqdet(i["caption"]["text"])
                        image = i["image_versions2"]["candidates"]
                        imageList = imageLists(image)
                        data = {'botName': botName, "owner": username, "mediaID": m, "caption": i["caption"]["text"],
                                "caption_lanq": lande,
                                "image": image, "imageList": imageList, 'image_dl': dl_m, "img_download": False,
                                "hashtags": hashtaghEx(i["caption"]["text"]),
                                "comment_likes_enabled": i["comment_likes_enabled"],
                                "comment_count": i["comment_count"],
                                "caption_is_edited": i["caption_is_edited"], "like_count": i["like_count"],
                                "likers": likers,
                                "commntes": coment, "full_crawl": True, 'date': date, 'counter': count}
                        # i = db.instagram_users_posts.insert_one(data)
                        kafkaproducer(jsn={"collections": "instagram_users_posts", "data": data}, botName=botName,
                                      topic="instagram_bot")
                        logmaker(bot="insta", kind="log", botName=botName,
                                 description="instagram_users_posts send to kafka 361 ")
                        #
                        # f = open("%s_resume.txt" % botName, "a+")
                        # f.write('\n' + str(m))
                        # f.close()

            except:
                print("Somthings wrong in get infos...")
                logmaker(bot="insta", kind="error", botName=botName, description="get infos error 375")


def profileScrap(botName,usernames,status,count,aut_man,dl_image=False):


    if status == 1:#start

        userid = []

        for i in usernames:
            userid.append(bot.get_user_id_from_username(username=i))

        sleep_counter = 50

        if aut_man == 1:

            while True:

                findC = db.instagram_user_ff.find({'bot_name': botName, 'crawl_status': False}).count()
                if findC > 0:
                    find = db.instagram_user_ff.find({'bot_name': botName, 'crawl_status': False})
                    for i in find:
                        follower_ids = i['followers']
                        following_ids = i['following']
                        for id in follower_ids:
                            userid.append(id)
                        for id in following_ids:
                            userid.append(id)

                    date = datetime.datetime.now()
                    update = db.instagram_user_ff.find({'bot_name': botName, 'crawl_status': False},
                                                       {"$set": {"crawl_status": True, 'date': date,'counter':count}}, True, True)

                if len(userid) == 0:
                    break

                con2: int = 0
                for user_id in userid:
                    scrape(user_id=user_id, botName=botName, status =status,count=count,dl_m=dl_image, sleep_counters=sleep_counter)
                    userid.remove(user_id)
                    con2 = int(con2) + 1
                    if con2 > sleep_counter:
                        time.sleep(300)
                        con2 = 0

        else:
            co: int = 0
            for user_id in userid:
                scrape(user_id=user_id, botName=botName, dl_m=dl_image, sleep_counters=sleep_counter)
                userid.remove(user_id)
                co = int(co) + 1
                if co > sleep_counter:
                    time.sleep(300)
                    co = 0


    if status == 0:#resume
        pass




#remove list b from list a
def modification(a,b):
    for x in b:
        try:
            a.remove(int(x))
        except ValueError:
            pass
    return a





def start_resume(bot_name):
    date = datetime.datetime.now()

    bot_name_find = db.bot_names.find({"bot_name": bot_name}).count()
    if bot_name_find == 0:
        bot_name_insert = db.bot_names.insert_one({'bot_name': bot_name, 'first_d': date, 'last_d': date, 'status': False, 'counter': 0})
        c = 0
        return 'start', c

    if bot_name_find > 0:
        bot_name_find = db.bot_names.find({'bot_name': bot_name})

        for i in bot_name_find:
            status = i['status']
            counter = i['counter']
            c = counter
            if status == True:
                update = db.bot_names.update_one({'bot_name': bot_name}, {"$set": {"status": False, 'last_d': date}},True, True)
                c = counter
                return 'start', c
            else:
                return 'resume', c





def RestFunc(username,password,crawl_usernames,dl_image=False,Aut_man=0,BotName='default'):
    '''
    :param username: username of instagram account for bot
    :param password: password of instagram account for bot
    :param Aut_man: 0 for Start Auto, 1 Man:
    :param BotName: name of bot.
    :param period:  period of bot-[roozaneh - d,haftegi - w ,mahaneh - m ,salaneh y]
    :param crawl_usernames: list of specific users for crawl
    :param consolTarget resume  1 , start with username  2.
    :return:
    '''

    try:

        bot.login(username=username, password=password)
        time.sleep(10)

    except RuntimeError as e:
        print('error')
        print(e)
        time.sleep(100)



    status,counter = start_resume(bot_name=BotName)
    newCounter = int(counter) + 1

    if status == 'start':

        path = mk_path(BotName=BotName)
        bot.base_path = path

        if len(crawl_usernames) == 0:
            crawl_usernames = ['parvizparastouei', 'panjare_nim']

        profileScrap(botName=BotName, usernames=crawl_usernames,status=1,count=newCounter, aut_man=Aut_man, dl_image=dl_image)

        update = db.bot_names.update_one({'bot_name': BotName}, {"$set": {"status": True, 'counter':newCounter }},True, True)
        return True



    if status == 'resume':
        path = mk_path(BotName=BotName)
        bot.base_path = path

        profileScrap(botName=BotName, usernames=crawl_usernames,status=0, count=counter, aut_man=Aut_man, dl_image=dl_image)

        update = db.bot_names.update_one({'bot_name': BotName}, {"$set": {"status": True, 'counter': newCounter}}, True, True)



    return True


RestFunc(username='sp_craw',password='NMAKZFNCHB#98',BotName='testi_man',dl_image=False,Aut_man=1,crawl_usernames=['v_amiri70'])