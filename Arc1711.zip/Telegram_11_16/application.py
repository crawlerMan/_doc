import os
import time
from flask import Flask, request,jsonify
from celery import Celery
from Telegram_scraper import authentication,main
from celery.exceptions import Ignore
import datetime
from celery.task.control import revoke

#-------------MongoDB Config-------------#
from pymongo import MongoClient
mongo_client = MongoClient('10.0.1.178:47017')
#mongo_client = MongoClient('localhost:27017')
db = mongo_client.telegram
#--------------*****----------------------#




app = Flask(__name__)

# Celery configuration - rabbitmq
app.config['CELERY_BROKER_URL'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/teleg_bot'
app.config['CELERY_RESULT_BACKEND'] = 'amqp://celery_bot:HNADZBE@10.0.1.234:5672/teleg_bot'

# app.config['CELERY_BROKER_URL'] = 'amqp://instaB:HNA123@localhost:5672/instabot'
# app.config['CELERY_RESULT_BACKEND'] = 'amqp://instaB:HNA123@localhost:5672/instabot'


# Celery configuration - mongodb
# app.config['CELERY_BROKER_URL'] = 'mongodb://localhost:27017/jobs'
# app.config['CELERY_RESULT_BACKEND'] = 'mongodb://localhost:27017/jobs'


# Initialize Celery
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)


@celery.task(bind=True)
def bot_start(self,*args,**kwargs):
    api_id  = args[0]
    api_hash=args[1]
    phone   =args[2]
    BotName =args[3]
    period  =args[4]
    search  =args[5]
    grLink  =args[6]
    chLink  =args[7]
    limit_g =args[8]
    limit_c = args[9]

    date = str(datetime.datetime.now())
    message = BotName + ' ' + "Started at %s" % date
    self.update_state(state='STARTED', meta={'message': message})
    time.sleep(1)
    message = BotName + ' ' + "is now Runnig"
    self.update_state(state='PROGRESS', meta={'message': message})
    time.sleep(1)
    x = main(bot_name=BotName,api_id=api_id,api_hash=api_hash,phone=phone,search=search,period=period,grLink=grLink,chLink=chLink,limit_g=limit_g,limit_c=limit_c)
    if x == 5:
        self.update_state(state='SUCCESS', meta={'message': 'Crawl was finished'})
        return {'status': 'Task completed!'}
    elif x == 4:
        self.update_state(state='FAILURE', meta={'message': 'Both grLink and chLink is empty!'})
        return Ignore()
    else:
        self.update_state(state='FAILURE', meta={'message': x})
        return Ignore()

    self.update_state(state='PROGRESS')
    time.sleep(1)
    return {'status': 'Task completed!'}



@app.route('/bot', methods=['POST'])
def bot():
    data = request.get_json()
    api_id   = data['api_id']
    api_hash = data['api_hash']
    phone    = data['phone']
    BotName  = data['bot_name']
    period   = data['period']
    search   = data['search']
    aut_code = data['aut_code']
    grLink   = data['grLink']
    chLink   = data['chLink']
    limit_g  = data['limit_g']
    limit_c = data['limit_c']

    mongo_data = {"api_id": api_id,"api_hash": api_hash,"phone": phone,"bot_name": BotName,
     "period": period,"search": search,"aut_code": aut_code,"grLink":grLink,"chLink": chLink,"limit_g":limit_g,"limit_c":limit_c}


    #i = db.telegram_bot.insert_one(mongo_data)

    x = authentication(api_id=api_id, api_hash=api_hash, phone=phone, aut_code=aut_code,bot_name=BotName)
    if x == 0:
        return jsonify({"message": "plz send aut code"}), 401
    # if x == 3:
    #     return jsonify({"message": "aut code is not correct!"}), 401
    elif x == 1:
        print("connect succesful")

        task = bot_start.apply_async(args=[api_id, api_hash, phone, BotName,
                                           period, search, grLink, chLink,limit_g,limit_c])
        return jsonify({"task_id":task.id}), 202
    else:
        x = str(x)
        return jsonify({"message": x}), 401

    x = str(x)
    return jsonify({"message": x}), 401




@app.route('/status/<task_id>')
def taskstatus(task_id):
    task = bot_start.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {
            'state': task.state,
            'status': 'Bot is runnig...'
        }
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'status': str(task.info)
        }
    else:
        # something went wrong in the background job
        response = {
            'state': task.state,
            'status': str(task.info)  # this is the exception raised
        }
    return jsonify(response)



@app.route('/revoke/<task_id>')
def revokes(task_id):
    x = revoke(task_id,Terminate = True, signal = 'SIGKILL')
    print(x)

    return jsonify({"message":srt(x)})




if __name__ == '__main__':
    app.run('0.0.0.0',port=5000,debug=True)
