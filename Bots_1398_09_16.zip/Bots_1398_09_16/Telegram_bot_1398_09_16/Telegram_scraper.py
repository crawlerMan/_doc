from datetime import timedelta
from persiantools.jdatetime import JalaliDateTime
from tkinter import dialog
import datetime
import time
import dateutil.parser
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv
import socks
import re
import os,pytz

#-------------MongoDB Config-------------#
from pymongo import MongoClient
mongo_client = MongoClient('localhost')
db = mongo_client.telegram
#--------------*****----------------------#


#--------------Log maker function----------------------#

def logmaker(bot="telegram",botName='default',kind=" ",description=" "):
	date = JalaliDateTime.now(pytz.timezone("Asia/Tehran")).strftime("%c")
	title = "Date & Time:              " + "\t" + "Bot Name:" + "\t   " + "Kind:" + "   \t" + "Description:" + "\t" + "\n"
	log = str(date) + "\t    " + str(botName) + "    \t     " + str(kind) + "\t     " + str(description) + "\t" + "\n"

	if bot =="fb":
		if os.path.exists("%s_fb_Log.txt" % botName):
			logFile = open("fb_Log.txt" % botName, "a+")
			logFile.write(log)
			logFile.close()

		else:
			with open("%s_fb_Log.txt" % botName, "w") as NewlogFile:
				NewlogFile.write(title)
				NewlogFile.write(log)
				NewlogFile.close()
	elif bot == "insta":
		if os.path.exists("%s_insta_Log.txt" % botName):
			logFile = open("%s_insta_Log.txt" % botName, "a+")
			logFile.write(log)
			logFile.close()

		else:
			with open("%s_insta_Log.txt" % botName, "w") as NewlogFile:
				NewlogFile.write(title)
				NewlogFile.write(log)
				NewlogFile.close()

	elif bot == "telegram":
		if os.path.exists("%s_telegram_Log.txt" % botName):
			logFile = open("%s_telegram_Log.txt" % botName, "a+")
			logFile.write(log)
			logFile.close()

		else:
			with open("%s_telegram_Log.txt" % botName, "w") as NewlogFile:
				NewlogFile.write(title)
				NewlogFile.write(log)
				NewlogFile.close()



#--------------Log maker function End ----------------------#

#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
	date = datetime.datetime.now()

	if kind == 'y':
		periodD = date + timedelta(days=365)

	if kind == 'm':
		periodD = date + timedelta(days=30)

	if kind == 'w':
		periodD = date + timedelta(days=7)

	if kind == 'd':
		periodD = date + timedelta(days=1)

	return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#


#-------------Kafka Config----------------#

from confluent_kafka import Producer
import json

def kafkaproducer(jsn,topic,botName='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    print(jsn)

def kafkaproducerN(jsn,topic,botName='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    data = str(jsn)

    def delivery_report(err, msg):
        """ Called once for each message produced to indicate delivery result.
            Triggered by poll() or flush(). """
        if err is not None:
            Kafkaerror='Message delivery failed: {}'.format(err)
            print(Kafkaerror)
            logmaker(bot="telegram", kind="error",botName=botName, description="kafka Message delivery failed - topic: %s " % topic)
            logmaker(bot="telegram", kind="error",botName=botName, description= Kafkaerror)

        else:
            print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))
    try:
        p = Producer({'bootstrap.servers': brokers})

    except:
        print("plz Check Kafka connections...")
        logmaker(bot="telegram", kind="error", botName=botName,description="kafka connections error ")
        time.sleep(10)
        pass

    try:
        # Trigger any available delivery report callbacks from previous produce() calls
        p.poll(0)
        p.produce(topic, data.encode('utf-8'), callback=delivery_report)

        p.flush()

    except:
        print("somethings wet wrong in kafka produce")
        logmaker(bot="telegram", kind="error", botName=botName,description="somethings wet wrong in kafka produce - topic: %s " % topic)

#--------------*****----------------------#

#--------------root path maker----------------------#


def mk_path(BotName='default'):

    bot_name_path = str(BotName)
    root_path = os.getcwd()
    root_path = root_path + '/telegram_bot'
    new_root_path = root_path + '/' + bot_name_path

    try:
        if os.path.exists(new_root_path):
            os.chdir(new_root_path)
        else:
            if os.path.exists(root_path):
                os.mkdir(new_root_path)
            else:
                os.mkdir(root_path)
                os.chdir(root_path)

                os.mkdir(new_root_path)
                os.chdir(new_root_path)

        print("Successfully open the directory %s " % new_root_path)
        logmaker(bot="telegram", kind="log", botName=BotName,
                 description="Successfully created the directory %s " % new_root_path)

        return new_root_path

    except OSError:
        print("Creation of the directory %s failed" % new_root_path)
        logmaker(bot="telegram", kind="error", botName=BotName,
                 description="Opening of the directory %s failed" % new_root_path)
#--------------root path maker end----------------------#



#estekhraj username_channels_groups
def extract_username(url):
    return re.search(r'https://t.me/([^/?]+)', url).group(1)

#estekhraj username_private_groups
def extract_pvgb_username(url):
    return re.search(r'https://t.me/joinchat/([^/?]+)', url).group(1)


#proxy = (socks.SOCKS5, '127.0.0.1', 9150)
import asyncio

def authentication(api_id,api_hash,phone,bot_name,aut_code):



    api_id = api_id
    api_hash = api_hash
    phone = phone
    root_path = os.getcwd()
    try:

        client = TelegramClient(session=root_path, api_id=api_id, api_hash=api_hash,loop=asyncio.set_event_loop(asyncio.new_event_loop()))

        # if client.is_user_authorized():
        #     return 1

        if aut_code == 0:
            client.connect()
            if not client.is_user_authorized():
                client.send_code_request(phone=phone,force_sms=True)
                return 0
        try:
            client.connect()
            print(phone)
            print(api_hash)

            client.sign_in(phone=str(phone), code=str(aut_code), phone_code_hash=str(api_hash))
            if client.is_user_authorized():
                return 1
            else:
                return 3
        except Exception as e:
            return e

    except Exception as e:
        print(e)



chats = []
last_date = None
chunk_size = 10000000
groups = []
channel = []




# ====================================گروه تلگرام==================
from telethon import errors
def telegramGroupExtract(botName='default',groupURL=None,search=None,period='n'):


    if groupURL !=None:
        g = ''
        if extract_username(groupURL) == "joinchat":
            username = extract_pvgb_username(url=groupURL)
        else:
            username = extract_username(url=groupURL)
        try:
            updates = client(ImportChatInviteRequest(username))
            g = client.get_entity(groupURL)

        except Exception as e:
            print(e)
            g = client.get_entity(groupURL)
            pass


        try:
            members = []

            print("group < %s > crawl start..." % g.title)

            findc = db.groups_info.find({"group_id": int(g.id)}).count()

            if findc == 0:
                print("strat fetching group < %s > " % g.title)

                try:
                    if g.id:
                        group_id = g.id
                    else:
                        group_id = ''

                    if g.username:
                        group_username = g.username
                    else:
                        group_username = ''

                    if g.title:
                        group_title = g.title

                    else:
                        group_title = ''

                    if g.date:
                        group_create_date = g.date

                    else:
                        group_create_date = ''

                    if g.access_hash:
                        group_access_hash = g.access_hash

                    else:
                        group_access_hash = ''

                    try:
                        print('Fetching Members...')
                        all_participants = []
                        all_participants = client.get_participants(g, aggressive=True)

                        for user in all_participants:
                            if user.username:
                                username = user.username
                            else:
                                username = ""
                            if user.id:
                                user_id = user.id
                            else:
                                user_id = ""
                            if user.phone:
                                phone_number = user.phone
                            else:
                                phone_number = ""
                            if user.first_name:
                                first_name = user.first_name
                            else:
                                first_name = ""
                            if user.last_name:
                                last_name = user.last_name
                            else:
                                last_name = ""

                            data_mem = {'botName':botName,"group_name": g.title, "group_id": g.id, "username": username,
                                        "user_id": user_id, "first_name": first_name,
                                        "last_name": last_name,
                                        "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                            try:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections":"telegram_group_people","data":data_mem},topic="telegram_bot")

                            except:
                                print("somethings wrong in mongo connection-telegram_people")

                            members.append(data_mem)

                    except:
                        print("somthings wrong in feteching members")
                        members = []
                        pass

                    now = datetime.datetime.now()
                    data = {'botName':botName,"group_id": int(group_id), "group_username": group_username, "group_title": group_title,
                            "group_create_date": group_create_date, "group_access_hash": group_access_hash,
                            "is_crawl": False,
                            "members": members,
                            "fetch_date": now}
                    print("< %s > Informations: " % group_username)
                    print(data)

                    try:
                        insert = db.groups_info.insert_one(data)
                        kafkaproducer({"collections": "groups_info", "data": data}, topic="telegram_bot")

                        print('Saving In Database...')
                        print('Members scraped successfully.')
                    except:
                        print("somethings wrong in mongo connection-group_info")

                    print("Start fetching last messages...")
                    messages = client.get_messages(g,search=search)

                    for message in messages:

                        if message.message:
                            message_txt = message.message
                        else:
                            message_txt = ""

                        if message.from_id:
                            user_id = message.from_id
                        else:
                            user_id = ""

                        if message.reply_to_msg_id:
                            reply_to_id = message.reply_to_msg_id

                        else:
                            reply_to_id = ""

                        if message.fwd_from:
                            froward_from = message.fwd_from
                        else:
                            froward_from = ""

                        if message.date:
                            date = message.date
                        else:
                            date = ""

                        data_group = {'botName':botName,"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                        try:
                            insert = db.groups_message_info.insert_one(data_group)
                            kafkaproducer({"collections": "groups_message_info", "data": data_group}, topic="telegram_bot")
                            time.sleep(1)

                        except:
                            print("somethings wrong in mongo connection-groups_message_info")

                        print("Messages fetched successfully")


                except:
                    print("somethings wrong in fetching groups...")
                    pass

            # agar ghablan crawl shoede bud
            if findc > 0:
                print("group %s is there." % g.title)

                savedMembers = []
                find_mem = db.telegram_group_people.find({"group_name": g.title})
                for i in find_mem:
                    savedMembers.append(int(i["user_id"]))

                try:
                    print('Fetching Members new members...')
                    all_participants = []
                    all_participants = client.get_participants(g, aggressive=True)

                    for user in all_participants:
                        if user.username:
                            username = user.username
                        else:
                            username = ""
                        if user.id:
                            user_id = int(user.id)
                        else:
                            user_id = ""
                        if user.phone:
                            phone_number = user.phone
                        else:
                            phone_number = ""
                        if user.first_name:
                            first_name = user.first_name
                        else:
                            first_name = ""
                        if user.last_name:
                            last_name = user.last_name
                        else:
                            last_name = ""

                        data_mem = {'botName':botName,"group_name": g.title, "group_id": g.id, "username": username, "user_id": user_id,
                                    "first_name": first_name, "last_name": last_name,
                                    "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                        try:
                            if user_id not in savedMembers:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                              topic="telegram_bot")

                                print("member %s saving in db." % username)

                            else:
                                print("member %s was saved in db." % username)

                        except:
                            print("somethings wrong in mongo connection-telegram_people")

                        members.append(data_mem)

                except:
                    print("somthings wrong in feteching members")
                    members = []
                    pass

                x = db.groups_message_info.find({"group_name": g.title}).limit(1).sort("$natural", 1)

                for d in x:
                    last_d = d["date"]

                print("Start fetching new 1000 messages...")
                messages = client.get_messages(g, 1000,search=search)

                for message in messages:

                    if message.message:
                        message_txt = message.message
                    else:
                        message_txt = ""

                    if message.from_id:
                        user_id = message.from_id
                    else:
                        user_id = ""

                    if message.reply_to_msg_id:
                        reply_to_id = message.reply_to_msg_id

                    else:
                        reply_to_id = ""

                    if message.fwd_from:
                        froward_from = message.fwd_from
                    else:
                        froward_from = ""

                    if message.date:
                        date = message.date
                    else:
                        date = ""

                    data_group_now = {'botName':botName,"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                    try:

                        if date.year == last_d.year:

                            if date.month == last_d.month:

                                if date.day == last_d.day:

                                    if date.hour > last_d.hour:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")

                                else:
                                    if date.day > last_d.day:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")
                            else:
                                if date.month > last_d.month:
                                    insert = db.groups_message_info.insert_one(data_group_now)
                                    kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                  topic="telegram_bot")
                        else:
                            if date.year > last_d.year:
                                insert = db.groups_message_info.insert_one(data_group_now)
                                kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                              topic="telegram_bot")

                    except:
                        print("somethings wrong in mongo connection-groups_message_info")

                print("Last new messages fetched...")


        except:
            print("somethings was wrong...")

    if groupURL == None:
        result = client(GetDialogsRequest(
            offset_date=last_date,
            offset_id=0,
            offset_peer=InputPeerEmpty(),
            limit=chunk_size,
            hash=0
        ))

        chats.extend(result.chats)
        # chats.extend(result.channels)

        for chat in chats:
            try:
                if chat.megagroup == True:
                    groups.append(chat)
            except:
                continue

        for g in groups:
            members = []

            print("group %s crawl start..." % g.title)

            findc = db.groups_info.find({"group_id": int(g.id)}).count()

            if findc == 0:
                print("strat fetching group %s " % g.title)

                try:
                    if g.id:
                        group_id = g.id
                    else:
                        group_id = ''

                    if g.username:
                        group_username = g.username
                    else:
                        group_username = ''

                    if g.title:
                        group_title = g.title

                    else:
                        group_title = ''

                    if g.date:
                        group_create_date = g.date

                    else:
                        group_create_date = ''

                    if g.access_hash:
                        group_access_hash = g.access_hash

                    else:
                        group_access_hash = ''

                    try:
                        print('Fetching Members...')
                        all_participants = []
                        all_participants = client.get_participants(g, aggressive=True)

                        for user in all_participants:
                            if user.username:
                                username = user.username
                            else:
                                username = ""
                            if user.id:
                                user_id = user.id
                            else:
                                user_id = ""
                            if user.phone:
                                phone_number = user.phone
                            else:
                                phone_number = ""
                            if user.first_name:
                                first_name = user.first_name
                            else:
                                first_name = ""
                            if user.last_name:
                                last_name = user.last_name
                            else:
                                last_name = ""

                            data_mem = {'botName':botName,"group_name": g.title, "group_id": g.id, "username": username,
                                        "user_id": user_id, "first_name": first_name,
                                        "last_name": last_name,
                                        "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                            try:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                              topic="telegram_bot")

                            except:
                                print("somethings wrong in mongo connection-telegram_people")

                            members.append(data_mem)

                    except:
                        print("somthings wrong in feteching members")
                        members = []
                        pass

                    now = datetime.datetime.now()
                    data = {'botName':botName,"group_id": int(group_id), "group_username": group_username, "group_title": group_title,
                            "group_create_date": group_create_date, "group_access_hash": group_access_hash,
                            "is_crawl": False,
                            "members": members,
                            "fetch_date": now}
                    print(data)

                    try:
                        insert = db.groups_info.insert_one(data)
                        kafkaproducer({"collections": "groups_info", "data": data},
                                      topic="telegram_bot")
                        print('Saving In Database...')
                        print('Members scraped successfully.')
                    except:
                        print("somethings wrong in mongo connection-group_info")

                    print("Start fetching last 1000 messages...")
                    messages = client.get_messages(g, 1000,search=search)

                    for message in messages:

                        if message.message:
                            message_txt = message.message
                        else:
                            message_txt = ""

                        if message.from_id:
                            user_id = message.from_id
                        else:
                            user_id = ""

                        if message.reply_to_msg_id:
                            reply_to_id = message.reply_to_msg_id

                        else:
                            reply_to_id = ""

                        if message.fwd_from:
                            froward_from = message.fwd_from
                        else:
                            froward_from = ""

                        if message.date:
                            date = message.date
                        else:
                            date = ""

                        data_group = {'botName':botName,"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                        try:
                            insert = db.groups_message_info.insert_one(data_group)
                            kafkaproducer({"collections": "groups_message_info", "data": data_group},
                                          topic="telegram_bot")


                        except:
                            print("somethings wrong in mongo connection-groups_message_info")

                    print("Messages fetched successfully")


                except:
                    print("somethings wrong in fetching groups...")
                    pass

            # agar ghablan crawl shoede bud
            if findc > 0:
                print("group %s is there." % g.title)

                savedMembers = []
                find_mem = db.telegram_group_people.find({"group_name": g.title})
                for i in find_mem:
                    savedMembers.append(int(i["user_id"]))

                try:
                    print('Fetching Members new members...')
                    all_participants = []
                    all_participants = client.get_participants(g, aggressive=True)

                    for user in all_participants:
                        if user.username:
                            username = user.username
                        else:
                            username = ""
                        if user.id:
                            user_id = int(user.id)
                        else:
                            user_id = ""
                        if user.phone:
                            phone_number = user.phone
                        else:
                            phone_number = ""
                        if user.first_name:
                            first_name = user.first_name
                        else:
                            first_name = ""
                        if user.last_name:
                            last_name = user.last_name
                        else:
                            last_name = ""

                        data_mem = {'botName':botName,"group_name": g.title, "group_id": g.id, "username": username, "user_id": user_id,
                                    "first_name": first_name, "last_name": last_name,
                                    "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                        try:
                            if user_id not in savedMembers:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                              topic="telegram_bot")
                                print("member %s saving in db." % username)

                            else:
                                print("member %s was saved in db." % username)

                        except:
                            print("somethings wrong in mongo connection-telegram_people")

                        members.append(data_mem)

                except:
                    print("somthings wrong in feteching members")
                    members = []
                    pass

                x = db.groups_message_info.find({"group_name": g.title}).limit(1).sort("$natural", 1)

                for d in x:
                    last_d = d["date"]

                print("Start fetching new 1000 messages...")
                messages = client.get_messages(g, 1000,search=search)

                for message in messages:

                    if message.message:
                        message_txt = message.message
                    else:
                        message_txt = ""

                    if message.from_id:
                        user_id = message.from_id
                    else:
                        user_id = ""

                    if message.reply_to_msg_id:
                        reply_to_id = message.reply_to_msg_id

                    else:
                        reply_to_id = ""

                    if message.fwd_from:
                        froward_from = message.fwd_from
                    else:
                        froward_from = ""

                    if message.date:
                        date = message.date
                    else:
                        date = ""

                    data_group_now = {"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                    try:

                        if date.year == last_d.year:

                            if date.month == last_d.month:

                                if date.day == last_d.day:

                                    if date.hour > last_d.hour:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")

                                else:
                                    if date.day > last_d.day:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")
                            else:
                                if date.month > last_d.month:
                                    insert = db.groups_message_info.insert_one(data_group_now)
                                    kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                  topic="telegram_bot")
                        else:
                            if date.year > last_d.year:
                                insert = db.groups_message_info.insert_one(data_group_now)
                                kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                              topic="telegram_bot")

                    except:
                        print("somethings wrong in mongo connection-groups_message_info")

                print("Last new messages fetched...")




def channelExtract(botName='default',username=None,period='n'):


    if username == None:


        # get all the channels that I can access
        channels = {d.entity.username: d.entity
                    for d in client.get_dialogs()
                    if d.is_channel}


        for i in channels:

            findc = db.channel_posts.find({"channel_name": i}).count()

            if findc == 0:
                ischannel = False
                messages = client.iter_messages(entity=i, limit=None)
                print("Start fetching messages of channel %s." % i)
                for k in messages:
                    if k.to_id.channel_id:
                        channel_id = k.to_id.channel_id
                    else:
                        channel_id = ''
                    if k.message:
                        message = k.message
                    else:
                        message = ""

                    if k.date:
                        date = k.date
                    else:
                        date = ''

                    if k.views:
                        views = k.views
                        ischannel = True
                    else:
                        views = ''
                    if i:
                        channel_name = i
                    else:
                        channel_name = ''

                    if ischannel:
                        data = {'botName':botName,"channel_name": channel_name, "channel_id": channel_id, "message": message,
                                "date": date,
                                "views": views}
                        insert = db.channel_posts.insert_one(data)
                        kafkaproducer({"collections": "channel_posts", "data": data},
                                      topic="telegram_bot")
                        print(data)
                print("all messages fetched...")

            if findc > 0:

                x = db.channel_posts.find({"channel_name":i}).limit(1).sort("$natural", 1)

                for d in x:
                    last_d = d["date"]

                ischannel = False
                messages = client.iter_messages(entity=i, limit=500)
                print("Start fetching new messages of channel %s." % i)
                for k in messages:
                    if k.to_id.channel_id:
                        channel_id = k.to_id.channel_id
                    else:
                        channel_id = ''
                    if k.message:
                        message = k.message
                    else:
                        message = ""

                    if k.date:
                        date = k.date
                    else:
                        date = ''

                    if k.views:
                        views = k.views
                        ischannel = True
                    else:
                        views = ''
                    if i:
                        channel_name = i
                    else:
                        channel_name = ''

                    if ischannel:
                        data_now = {'botName':botName,"channel_name": channel_name, "channel_id": channel_id, "message": message,
                                    "date": date,
                                    "views": views}

                        if date.year == last_d.year:

                            if date.month == last_d.month:

                                if date.day == last_d.day:

                                    if date.hour > last_d.hour:
                                        insert = db.channel_posts.insert_one(data_now)
                                        kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                      topic="telegram_bot")

                                else:
                                    if date.day > last_d.day:
                                        insert = db.channel_posts.insert_one(data_now)
                                        kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                      topic="telegram_bot")
                            else:
                                if date.month > last_d.month:
                                    insert = db.channel_posts.insert_one(data_now)
                                    kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                  topic="telegram_bot")
                        else:
                            if date.year > last_d.year:
                                insert = db.channel_posts.insert_one(data_now)
                                kafkaproducer({"collections": "channel_posts", "data": data_now},
                                              topic="telegram_bot")

                print("all new messages fetched...")

    #agar username ya url dashtim
    if username != None:

        g = ''
        if extract_username(username) == "joinchat":
            username = extract_pvgb_username(url=username)
        else:
            username = extract_username(url=username)
        try:
            updates = client(ImportChatInviteRequest(username))
            g = client.get_entity(username)

        except Exception as e:
            print(e)
            g = client.get_entity(username)
            pass

        channel_entity = client.get_entity(g)
        channel_n = channel_entity.title

        findc = db.channel_posts.find({"channel_name": channel_n}).count()

        if findc == 0:
            ischannel = False
            messages = client.iter_messages(entity=channel_entity.title, limit=None)
            print("Start fetching messages of channel %s." % channel_n)
            for k in messages:
                if k.to_id.channel_id:
                    channel_id = k.to_id.channel_id
                else:
                    channel_id = ''
                if k.message:
                    message = k.message
                else:
                    message = ""

                if k.date:
                    date = k.date
                else:
                    date = ''

                if k.views:
                    views = k.views
                    ischannel = True
                else:
                    views = ''
                if channel_n:
                    channel_name = channel_n
                else:
                    channel_name = ''

                if ischannel:
                    data = {'botName':botName,"channel_name": channel_name, "channel_id": channel_id, "message": message,
                            "date": date,
                            "views": views}
                    insert = db.channel_posts.insert_one(data)
                    kafkaproducer({"collections": "channel_posts", "data": data},
                                  topic="telegram_bot")
            print("all messages fetched...")

        if findc > 0:

            x = db.channel_posts.find({"channel_name": channel_n}).limit(1).sort("$natural", 1)

            for d in x:
                last_d = d["date"]

            ischannel = False
            messages = client.iter_messages(entity=channel_n, limit=500)
            print("Start fetching new messages of channel %s." % channel_n)
            for k in messages:
                if k.to_id.channel_id:
                    channel_id = k.to_id.channel_id
                else:
                    channel_id = ''
                if k.message:
                    message = k.message
                else:
                    message = ""

                if k.date:
                    date = k.date
                else:
                    date = ''

                if k.views:
                    views = k.views
                    ischannel = True
                else:
                    views = ''
                if channel_n:
                    channel_name = channel_n
                else:
                    channel_name = ''

                if ischannel:
                    data_now = {'botName':botName,"channel_name": channel_name, "channel_id": channel_id, "message": message,
                                "date": date,
                                "views": views}

                    if date.year == last_d.year:

                        if date.month == last_d.month:

                            if date.day == last_d.day:

                                if date.hour > last_d.hour:
                                    insert = db.channel_posts.insert_one(data_now)
                                    kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                  topic="telegram_bot")


                            else:
                                if date.day > last_d.day:
                                    insert = db.channel_posts.insert_one(data_now)
                                    kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                  topic="telegram_bot")
                        else:
                            if date.month > last_d.month:
                                insert = db.channel_posts.insert_one(data_now)
                                kafkaproducer({"collections": "channel_posts", "data": data_now},
                                              topic="telegram_bot")
                    else:
                        if date.year > last_d.year:
                            insert = db.channel_posts.insert_one(data_now)
                            kafkaproducer({"collections": "channel_posts", "data": data_now},
                                          topic="telegram_bot")
            print("all new messages fetched...")




#group function
#telegramGroupExtract()
#channel function
#channelExtract()

#==========================join to channel ==============================



def channel_queue(url=None):
    if url != None:
        username = extract_username(url)
        join = client(JoinChannelRequest(username))
        update = db.channel_queue.update({"url": url}, {"$set": {"is_join": True}}, upsert=True,
                                         multi=True)
    else:
        find = db.channel_queue.find({"is_join": False})
        try:
            for i in find:
                username = extract_username(i["url"])
                join = client(JoinChannelRequest(username))
                try:
                    update = db.channel_queue.update({"url": i["url"]}, {"$set": {"is_join": True}}, upsert=False,
                                                     multi=False)
                except:
                    print("somethings wrong - mongodb update")
        except:
            print("somethings wrong - join channel %s." % i)



# https://t.me/joinchat/AAAAAFFszQPyPEZ7wgxLtd
# ===========================join private group==================================

def join_private_group(url=None):
    if url !=None:
        username = extract_pvgb_username(url)
        try:
            updates = client(ImportChatInviteRequest(username))
            update = db.private_gb_queue.update({"url":url}, {"$set": {"is_join": True}}, upsert=True,
                                                multi=True)
        except:
            print("somethings wrong in join pv group")

    else:

        find = db.private_gb_queue.find({"is_join": False})
        for i in find:
            username = extract_pvgb_username(i["url"])

            try:
                join = client(ImportChatInviteRequest(username))
                try:
                    update = db.private_gb_queue.update({"url":i["url"]},{"$set":{"is_join": True}},upsert=False, multi=True)

                except:
                    print("somethings wrong - mongodb update")

            except:
                print("somethings wrong in join pv group %s." % username)
                pass




def main(bot_name,api_id,api_hash,phone,manual=1,period='n',func='gr',grLink=None,chLink=None,aut_code=0):
    mk_path(BotName=bot_name)
    if aut_code == 0:
        mk_path(BotName=bot_name)

    #x = authentication(api_id=api_id,api_hash=api_hash,phone=phone,aut_code=aut_code)
    if period == 'n':
            if func == 'gr':
                telegramGroupExtract(botName=bot_name,groupURL=grLink)
            elif func == 'ch':
                channelExtract(botName=bot_name,username=chLink)

    else:
        while True:
            periodDate = periodCal(kind=period)
            if func == 'gr':
                telegramGroupExtract(botName=bot_name, groupURL=grLink, period=periodDate)
            elif func == 'ch':
                channelExtract(botName=bot_name, username=chLink, period=periodDate)
            time.sleep(bot_sleep_time(period=periodDate))

    # if x != 1:
    #     return x
    # else:
    #     if period == 'n':
    #         if func == 'gr':
    #             telegramGroupExtract(botName=bot_name,groupURL=grLink)
    #         elif func == 'ch':
    #             channelExtract(botName=bot_name,username=chLink)
    #
    #     else:
    #         while True:
    #             periodDate = periodCal(kind=period)
    #             if func == 'gr':
    #                 telegramGroupExtract(botName=bot_name,groupURL=grLink,period=periodDate)
    #             elif func == 'ch':
    #                 channelExtract(botName=bot_name,username=chLink,period=periodDate)
    #             time.sleep(bot_sleep_time(period=periodDate))


    return 1
# root_path = os.getcwd()
#
# try:
#     client = TelegramClient(session=root_path,api_id=1041093, api_hash='d505509f2ccdef0fdca28b8cd148e219')
#     client.connect()
# except Exception as e:
#     print(e)
#
# if not client.is_user_authorized():
#     client.send_code_request(989128439547)
#
#     try:
#         client.sign_in(phone=989128439547, code=input("inter code...\n"), phone_code_hash='d505509f2ccdef0fdca28b8cd148e219')
#         if client.is_user_authorized():
#             print('connect')
#     except Exception as e:
#       print(e)
#
#



#x =authentication(bot_name='sara',api_id=796906,api_hash='80a4ef01149c6c639b815cafbd3aab49',phone=989192683701,aut_code=57070)
#print(x)


api_id = 1041093
api_hash = 'd505509f2ccdef0fdca28b8cd148e219'
phone = 989128439547
root_path = os.getcwd()

client = TelegramClient(session=root_path, api_id=api_id, api_hash=api_hash,loop=asyncio.set_event_loop(asyncio.new_event_loop()))


client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone=phone,force_sms=True)
    client.sign_in(phone=str(phone), code=input("Enter code..."), phone_code_hash=str(api_hash))
    if client.is_user_authorized():
        print('ok')
    else:
        print('ohhhhh')