


def rest_bot(jsn,function):
	function == 'update'

	if function == 'start':
		findc = db.rest_api.find(jsn).count()
		if findc == 0:
			insert = db.rest_api.insert_one(jsn)
		else:
			update =