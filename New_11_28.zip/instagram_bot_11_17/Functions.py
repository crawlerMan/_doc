from textblob import TextBlob
import emoji
import re



#--------------*****----------------------#

def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 50, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total:
        print()


#-------------Neo4j Config-------------#

from py2neo import Node,Database, Graph,Relationship,NodeMatcher

gr = Graph(password='HNADZBE')
matcher = NodeMatcher(gr)

#-------------Neo4j Config End -------------#




#--------------Log maker function----------------------#

def logmaker(bot="insta",botName='default',kind=" ",description=" "):
	date = JalaliDateTime.now(pytz.timezone("Asia/Tehran")).strftime("%c")
	title = "Date & Time:              " + "\t" + "Bot Name:" + "\t   " + "Kind:" + "   \t" + "Description:" + "\t" + "\n"
	log = str(date) + "\t    " + str(botName) + "    \t     " + str(kind) + "\t     " + str(description) + "\t" + "\n"

	if os.path.exists("%s_%s_Log.txt" % (botName, bot)):
		logFile = open("%s_%s_Log.txt" % (botName, bot), "a+")
		logFile.write(log)
		logFile.close()

	else:
		with open("%s_%s_Log.txt" % (botName, bot), "w") as NewlogFile:
			NewlogFile.write(title)
			NewlogFile.write(log)
			NewlogFile.close()



#--------------Log maker function End ----------------------#

#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
    date = datetime.datetime.now()

    if kind == 'y':
        periodD = date + timedelta(days=365)

    if kind == 'm':
        periodD = date + timedelta(days=30)

    if kind == 'w':
        periodD = date + timedelta(days=7)

    if kind == 'd':
        periodD = date + timedelta(days=1)

    if kind == 'n':
        periodD = date

    return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#


#-------------Kafka Config----------------#

from confluent_kafka import Producer
import json

def kafkaproducer(jsn,topic,botName='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    print(jsn)

def kafkaproducerN(jsn,topic,botName='default',brokers = '10.0.1.183:9091,10.0.1.184:9093,10.0.1.185:9094'):
    data = str(jsn)

    def delivery_report(err, msg):
        """ Called once for each message produced to indicate delivery result.
            Triggered by poll() or flush(). """
        if err is not None:
            Kafkaerror='Message delivery failed: {}'.format(err)
            print(Kafkaerror)
            logmaker(bot="insta", kind="error",botName=botName, description="kafka Message delivery failed - topic: %s " % topic)
            logmaker(bot="insta", kind="error",botName=botName, description= Kafkaerror)

        else:
            print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))
    try:
        p = Producer({'bootstrap.servers': brokers})

    except:
        print("plz Check Kafka connections...")
        logmaker(bot="insta", kind="error", botName=botName,description="kafka connections error ")
        time.sleep(10)
        pass

    try:
        # Trigger any available delivery report callbacks from previous produce() calls
        p.poll(0)
        p.produce(topic, data.encode('utf-8'), callback=delivery_report)

        p.flush()

    except:
        print("somethings wet wrong in kafka produce")
        logmaker(bot="insta", kind="error", botName=botName,description="somethings wet wrong in kafka produce - topic: %s " % topic)

#--------------*****----------------------#

#--------------root path maker----------------------#


def mk_path(BotName='default'):
    bot_name_path = str(BotName)
    root_path = os.getcwd()
    root_path = root_path + '/instagram_bot'
    new_root_path = root_path + '/' + bot_name_path

    try:
        if os.path.exists(new_root_path):
            os.chdir(new_root_path)
        else:
            if os.path.exists(root_path):
                os.mkdir(new_root_path)
            else:
                os.mkdir(root_path)
                os.chdir(root_path)

                os.mkdir(new_root_path)
                os.chdir(new_root_path)

        print("Successfully open the directory %s " % new_root_path)
        logmaker(bot="insta", kind="log", botName=BotName,
                 description="Successfully created the directory %s " % new_root_path)

        return new_root_path

    except OSError:
        print("Creation of the directory %s failed" % new_root_path)
        logmaker(bot="insta", kind="error", botName=BotName,
                 description="Opening of the directory %s failed" % new_root_path)
#--------------root path maker end----------------------#


#-------------Neo4j Insert -------------#

def neo4j_insert(username, user_id, follower_list, following_List):
    pass

def neo4j_insert_n(username, user_id, follower_list, following_List):


    if (matcher.match("Insta_Users", user_id=user_id).first() == None):
        try:
            owner = Node("Insta_Users", username=username, user_id=user_id)
            gr.create(owner)
        except Exception as e:
            print (e)
    else:
        try:
            owner = matcher.match("Insta_Users", user_id=user_id).first()
        except Exception as e:
            print (e)
    ff_c = 0
    follower_list_c = len(follower_list)
    for ff_er in follower_list:
        if (matcher.match("Insta_Users", user_id=ff_er).first() == None):
            try:
                a = Node("Insta_Users", user_id=user_id)
                gr.create(a)
            except Exception as e:
                print (e)

        else:
            try:
                a = matcher.match("Insta_Users", user_id=ff_er).first()
            except Exception as e:
                print (e)
        try:
            a_owner = Relationship(a, "FOLLOW", owner)
            gr.create(a_owner)
        except Exception as e:
            print (e)

        printProgressBar(iteration=ff_c, total=follower_list_c, prefix='==> %s follower list insert Neo4j progress:' % username,
                         suffix='Complete')


    ff_c = 0
    following_List_len = len(following_List)
    for ff_in in following_List:
        if (matcher.match("Insta_Users", user_id=ff_in).first() == None):
            try:
                a = Node("Insta_Users", user_id=user_id)
                gr.create(a)
            except Exception as e:
                print (e)
            else:
                try:
                    a = matcher.match("Insta_Users", user_id=ff_in).first()
                except Exception as e:
                    print (e)
        try:
            owner_a = Relationship(owner, "FOLLOW", a)
            gr.create(owner_a)
            print(owner_a)
        except Exception as e:
            print (e)

        printProgressBar(iteration=ff_c, total=following_List_len,
                         prefix='==> %s following list insert Neo4j progress:' % username,
                         suffix='Complete')


#-------------Neo4j Insert-------------#


#image extractor from json
def imageLists(img):
    for k in img:
        imageList = []
        width = k["width"]
        height = k["height"]
        url = k["url"]
        #binary = picToBinary(url)
        imageList.append({"width": width, "height": height, "url": url})
    return imageList

#remove list b from list a
def modification(a,b):
    for x in b:
        try:
            a.remove(int(x))
        except ValueError:
            pass
    return a



def removeStr(t):
    regex = re.compile(r'[\n\r\t]')
    t = regex.sub('',t)
    t = t.rstrip()
    return t

#remove hashtag
def hashtaghEx(s):
    t = remove_emoji(s)
    return re.findall(r"#(\w+)", t)

#remove emoji from text
def remove_emoji(text):
    return emoji.get_emoji_regexp().sub(u'', text)


#joda kardan kalamat
def spliteKeyWord(s):
    #s = re.sub(r'\s', '', s)
    s = s.replace(r"\n", " ")
    return re.findall(r'[\dA-Za-z]+|[^\dA-Za-z\W]+', s, re.UNICODE)


#tashkhis zaban
def lanqdet(text):

    if text == None:
        return "null"

    lanList = []
    listStop = ['aber', 'alle', 'allem', 'allen', 'aller', 'alles', 'als', 'also', 'am', 'an', 'ander', 'andere', 'anderem',
          'anderen', 'anderer', 'anderes', 'anderm', 'andern', 'anders', 'auch', 'auf', 'aus', 'bei', 'bin', 'bis',
          'bist', 'da', 'damit', 'dann', 'das', 'dass', 'dasselbe', 'dazu', 'daß', 'dein', 'deine', 'deinem', 'deinen',
          'deiner', 'deines', 'dem', 'demselben', 'den', 'denn', 'denselben', 'der', 'derer', 'derselbe', 'derselben',
          'des', 'desselben', 'dessen', 'dich', 'die', 'dies', 'diese', 'dieselbe', 'dieselben', 'diesem', 'diesen',
          'dieser', 'dieses', 'dir', 'doch', 'dort', 'du', 'durch', 'ein', 'eine', 'einem', 'einen', 'einer', 'eines',
          'einig', 'einige', 'einigem', 'einigen', 'einiger', 'einiges', 'einmal', 'er', 'es', 'etwas', 'euch', 'euer',
          'eure', 'eurem', 'euren', 'eurer', 'eures', 'für', 'gegen', 'gewesen', 'hab', 'habe', 'haben', 'hat', 'hatte',
          'hatten', 'hier', 'hin', 'hinter', 'ich', 'ihm', 'ihn', 'ihnen', 'ihr', 'ihre', 'ihrem', 'ihren', 'ihrer',
          'ihres', 'im', 'in', 'indem', 'ins', 'ist', 'jede', 'jedem', 'jeden', 'jeder', 'jedes', 'jene', 'jenem',
          'jenen', 'jener', 'jenes', 'jetzt', 'kann', 'kein', 'keine', 'keinem', 'keinen', 'keiner', 'keines', 'können',
          'könnte', 'machen', 'man', 'manche', 'manchem', 'manchen', 'mancher', 'manches', 'mein', 'meine', 'meinem',
          'meinen', 'meiner', 'meines', 'mich', 'mir', 'mit', 'muss', 'musste', 'nach', 'nicht', 'nichts', 'noch',
          'nun', 'nur', 'ob', 'oder', 'ohne', 'sehr', 'sein', 'seine', 'seinem', 'seinen', 'seiner', 'seines', 'selbst',
          'sich', 'sie', 'sind', 'so', 'solche', 'solchem', 'solchen', 'solcher', 'solches', 'soll', 'sollte',
          'sondern', 'sonst', 'um', 'und', 'uns', 'unser', 'unsere', 'unserem', 'unseren', 'unserer', 'unseres',
          'unter', 'viel', 'vom', 'von', 'vor', 'war', 'waren', 'warst', 'was', 'weg', 'weil', 'weiter', 'welche',
          'welchem', 'welchen', 'welcher', 'welches', 'wenn', 'werde', 'werden', 'wie', 'wieder', 'will', 'wir', 'wird',
          'wirst', 'wo', 'wollen', 'wollte', 'während', 'würde', 'würden', 'zu', 'zum', 'zur', 'zwar', 'zwischen',
          'über', 'فى', 'في', 'كل', 'لم', 'لن', 'له', 'من', 'هو', 'هي', 'قوة', 'كما', 'لها', 'منذ', 'وقد', 'ولا',
          'نفسه',
          'لقاء', 'مقابل', 'هناك', 'وقال', 'وكان', 'نهاية', 'وقالت', 'وكانت', 'للامم', 'فيه', 'كلم', 'لكن', 'وفي',
          'وقف', 'ولم', 'ومن', 'وهو', 'وهي', 'يوم', 'فيها', 'منها', 'مليار', 'لوكالة', 'يكون', 'يمكن', 'مليون', 'حيث',
          'اكد', 'الا', 'اما', 'امس', 'السابق', 'التى', 'التي', 'اكثر', 'ايار', 'ايضا', 'ثلاثة', 'الذاتي', 'الاخيرة',
          'الثاني', 'الثانية', 'الذى', 'الذي', 'الان', 'امام', 'ايام', 'خلال', 'حوالى', 'الذين', 'الاول', 'الاولى',
          'بين', 'ذلك', 'دون', 'حول', 'حين', 'الف', 'الى', 'انه', 'اول', 'ضمن', 'انها', 'جميع', 'الماضي', 'الوقت',
          'المقبل', 'اليوم', 'ـ', 'ف', 'و', 'و6', 'قد', 'لا', 'ما', 'مع', 'مساء', 'هذا', 'واحد', 'واضاف', 'واضافت',
          'فان', 'قبل', 'قال', 'كان', 'لدى', 'نحو', 'هذه', 'وان', 'واكد', 'كانت', 'واوضح', 'مايو', 'ب', 'ا', 'أ', '،',
          'عشر', 'عدد', 'عدة', 'عشرة', 'عدم', 'عام', 'عاما', 'عن', 'عند', 'عندما', 'على', 'عليه', 'عليها', 'زيارة',
          'سنة', 'سنوات', 'تم', 'ضد', 'بعد', 'بعض', 'اعادة', 'اعلنت', 'بسبب', 'حتى', 'اذا', 'احد', 'اثر', 'برس', 'باسم',
          'غدا', 'شخصا', 'صباح', 'اطار', 'اربعة', 'اخرى', 'بان', 'اجل', 'غير', 'بشكل', 'حاليا', 'بن', 'به', 'ثم', 'اف',
          'ان', 'او', 'اي', 'بها', 'صفر', 'أن', 'ه', 'شد', 'a', 'about', 'above', 'after', 'again', 'against', 'all',
          'am', 'an', 'and', 'any', 'are', "aren't", 'as',
          'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', "can't", 'cannot',
          'could', "couldn't", 'did', "didn't", 'do', 'does', "doesn't", 'doing', "don't", 'down', 'during', 'each',
          'few', 'for', 'from', 'further', 'had', "hadn't", 'has', "hasn't", 'have', "haven't", 'having', 'he', "he'd",
          "he'll", "he's", 'her', 'here', "here's", 'hers', 'herself', 'him', 'himself', 'his', 'how', "how's", 'i',
          "i'd", "i'll", "i'm", "i've", 'if', 'in', 'into', 'is', "isn't", 'it', "it's", 'its', 'itself', "let's", 'me',
          'more', 'most', "mustn't", 'my', 'myself', 'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or',
          'other', 'ought', 'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', "shan't", 'she', "she'd",
          "she'll", "she's", 'should', "shouldn't", 'so', 'some', 'such', 'than', 'that', "that's", 'the', 'their',
          'theirs', 'them', 'themselves', 'then', 'there', "there's", 'these', 'they', "they'd", "they'll", "they're",
          "they've", 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', "wasn't", 'we',
          "we'd", "we'll", "we're", "we've", 'were', "weren't", 'what', "what's", 'when', "when's", 'where', "where's",
          'which', 'while', 'who', "who's", 'whom', 'why', "why's", 'with', "won't", 'would', "wouldn't", 'you',
          "you'd", "you'll", "you're", "you've", 'your', 'yours', 'yourself', 'yourselves', 'a', 'ai', 'aie', 'aient',
          'aies', 'ait', 'alors', 'as', 'au', 'aucun', 'aura', 'aurai', 'auraient',
          'aurais', 'aurait', 'auras', 'aurez', 'auriez', 'aurions', 'aurons', 'auront', 'aussi', 'autre', 'aux',
          'avaient', 'avais', 'avait', 'avant', 'avec', 'avez', 'aviez', 'avions', 'avoir', 'avons', 'ayant', 'ayez',
          'ayons', 'bon', 'car', 'ce', 'ceci', 'cela', 'ces', 'cet', 'cette', 'ceux', 'chaque', 'ci', 'comme',
          'comment', 'd', 'dans', 'de', 'dedans', 'dehors', 'depuis', 'des', 'deux', 'devoir', 'devrait', 'devrez',
          'devriez', 'devrions', 'devrons', 'devront', 'dois', 'doit', 'donc', 'dos', 'droite', 'du', 'dès', 'début',
          'dù', 'elle', 'elles', 'en', 'encore', 'es', 'est', 'et', 'eu', 'eue', 'eues', 'eurent', 'eus', 'eusse',
          'eussent', 'eusses', 'eussiez', 'eussions', 'eut', 'eux', 'eûmes', 'eût', 'eûtes', 'faire', 'fais', 'faisez',
          'fait', 'faites', 'fois', 'font', 'force', 'furent', 'fus', 'fusse', 'fussent', 'fusses', 'fussiez',
          'fussions', 'fut', 'fûmes', 'fût', 'fûtes', 'haut', 'hors', 'ici', 'il', 'ils', 'j', 'je', 'juste', 'l',
          'la', 'le', 'les', 'leur', 'leurs', 'lui', 'là', 'm', 'ma', 'maintenant', 'mais', 'me', 'mes', 'moi',
          'moins', 'mon', 'mot', 'même', 'n', 'ne', 'ni', 'nom', 'nommé', 'nommée', 'nommés', 'nos', 'notre', 'nous',
          'nouveau', 'nouveaux', 'on', 'ont', 'ou', 'où', 'par', 'parce', 'parole', 'pas', 'personne', 'personnes',
          'peu', 'peut', 'plupart', 'pour', 'pourquoi', 'qu', 'quand', 'que', 'quel', 'quelle', 'quelles', 'quels',
          'qui', 'sa', 'sans', 'se', 'sera', 'serai', 'seraient', 'serais', 'serait', 'seras', 'serez', 'seriez',
          'serions', 'serons', 'seront', 'ses', 'seulement', 'si', 'sien', 'soi', 'soient', 'sois', 'soit', 'sommes',
          'son', 'sont', 'sous', 'soyez', 'soyons', 'suis', 'sujet', 'sur', 't', 'ta', 'tandis', 'te', 'tellement',
          'tels', 'tes', 'toi', 'ton', 'tous', 'tout', 'trop', 'très', 'tu', 'un', 'une', 'valeur', 'voient', 'vois',
          'voit', 'vont', 'vos', 'votre', 'vous', 'vu', 'y', 'à', 'ça', 'étaient', 'étais', 'était', 'étant', 'état',
          'étiez', 'étions', 'été', 'étés', 'êtes', 'être', "ها", "برای", "که", "را", "می", "تا", "و", "آن", "هم", "نه",
          "نیز", "لیکن", "اما", "یا", "اگر", "بلکه",
          "ازبس", "دو", "یک", "بر", "به", "شما", "او", "من", "ش", "اش", "ات", "ام", "پی", "سه", "چهار", "پنج", "شش",
          "ششم", "هفت", "هشت", "نه", "ده", "هم", "هی", "از", "در", "با", ]

    t = remove_emoji(text)
    i = spliteKeyWord(t)

    filtered_fr = [w for w in i if not w in listStop]
    i = 0
    for j in filtered_fr:
        try:
            b = TextBlob(j)
            x = b.detect_language()
            lanList.append(x)
            i = i + 1
        except:
            pass
    x = dict((x, lanList.count(x)) for x in set(lanList))
    c = 0
    for x,y in x.items():
        c = (y / i) * 100
        if c > 50:
            return x
        else:
            return "unknown"


#--------------period and sleeping function ----------------------#
def bot_sleep_time(period):
	date = datetime.datetime.now()
	pdate_obj = datetime.datetime.strptime(period, '%Y-%m-%d-%H')
	sub = pdate_obj - date
	out = sub.days
	if out == 0:
		return sub.seconds
	return (out * 24 * 3600)
#-------------- period and sleeping function End ----------------------#

#-------------- period cal function  ----------------------#

def periodCal(kind='y'):
    date = datetime.datetime.now()

    if kind == 'y':
        periodD = date + timedelta(days=365)

    if kind == 'm':
        periodD = date + timedelta(days=30)

    if kind == 'w':
        periodD = date + timedelta(days=7)

    if kind == 'd':
        periodD = date + timedelta(days=1)

    if kind == 'n':
        periodD = date

    return periodD.strftime('%Y-%m-%d-%H')

#-------------- period cal function End ----------------------#


#-------------- Neo4j Query function  ----------------------#

def result_neo4j(user_a,user_b):

	if type(user_a) and type(user_b) == int:
		cqlShorestPath = """MATCH (p1:Users { user_id: %d }),(p2:Users { user_id: %d }), 
								path = shortestPath((p1)-[*..500]-(p2))
								RETURN extract (n in nodes(path))""" % (user_a, user_b)

	else:
		cqlShorestPath = """MATCH (p1:Users { username: %d }),(p2:Users { username: %d }), 
								path = shortestPath((p1)-[*..500]-(p2))
								RETURN extract (n in nodes(path))""" % (user_a, user_b)

	result = gr.evaluate(cqlShorestPath)

	lenOfPath =len(result)
	path = []
	c = 0
	for i in result:
		path.append({'number': c, 'username': i['username'], 'user_id': i['user_id']})
		c = int(c) + 1

	data = {'from': user_a, 'to': user_b, 'len': lenOfPath, 'path': path}

	return data

#-------------- Neo4j Query function End ----------------------#