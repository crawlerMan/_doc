import os
from persiantools.jdatetime import JalaliDateTime
import os,pytz


def logmaker(bot="fb",botName='default',kind=" ",description=" "):

	date = JalaliDateTime.now(pytz.timezone("Asia/Tehran")).strftime("%c")
	title = "Date & Time:              " + "\t" + "Bot Name:" + "\t   " + "Kind:" + "   \t" + "Description:" + "\t" + "\n"
	log = str(date) + "\t    " + str(botName) + "    \t     " + str(kind) + "\t     " + str(description) + "\t" + "\n"

	if os.path.exists("%s_%s_Log.txt" % (botName, bot)):
		logFile = open("%s_%s_Log.txt" % (botName, bot), "a+")
		logFile.write(log)
		logFile.close()

	else:
		with open("%s_%s_Log.txt" % (botName, bot), "w") as NewlogFile:
			NewlogFile.write(title)
			NewlogFile.write(log)
			NewlogFile.close()




def neo4j_insert(username,friends,bot_name):

	try:
		if (matcher.match("FaceBookUsers", user_id=username).first() == None):
			owner = Node("FaceBookUsers", username=username)
			gr.create(owner)
		else:
			owner = matcher.match("FaceBookUsers", username=username).first()
	except Exception as e:
		print ("somethings worong in insert owner in Neo4j")
        logmaker(botName=bot_name, kind='log', description='somethings went wrong in Neo4j func - error: %s' % e)

try:
		for friend in friends:

			if (matcher.match("FaceBookUsers", username=friend).first() == None):
				a = Node("FaceBookUsers", username=str(friend))
				gr.create(a)
			else:
				a = matcher.match("FaceBookUsers", username=friend).first()

			a_owner = Relationship(a, "Friend", owner)
			gr.create(a_owner)
	except Exception as e:
		print ("somethings worong in insert followers in Neo4j")
		logmaker(botName=bot_name, kind='log', description='somethings went wrong in Neo4j func - error: %s' % e)
