from pymongo import MongoClient
client = MongoClient('localhost')
db = client.telegram
import time,shutil


def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 50, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    @params:
        iteration   - Required  : current iteration (Int)
        total       - Required  : total iterations (Int)
        prefix      - Optional  : prefix string (Str)
        suffix      - Optional  : suffix string (Str)
        decimals    - Optional  : positive number of decimals in percent complete (Int)
        length      - Optional  : character length of bar (Int)
        fill        - Optional  : bar fill character (Str)
        printEnd    - Optional  : end character (e.g. "\r", "\r\n") (Str)
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total:
        print()


def phoneNumberGenerator():
	Irancell = [901, 902, 930, 933, 935, 936, 937, 938, 939]
	MCI = [910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 990, 991, 992]
	Talia = [932]
	Rightel = [920, 921, 922]
	spadan = [931]
	teleKish = [934]
	ApTel = [99910, 99911, 99913]
	AzarTel = [99914]
	SamaTel = [99999, 99998, 99997, 99996]
	Lotustel = [9990]
	shatel = [99810, 99811, 99812]
	Anarestan = [9944]

	precode = {"Irancell": Irancell, "MCI": MCI, "Talia": Talia, "Rightel": Rightel, "spadan": spadan,
	           "teleKish": teleKish, "ApTel": ApTel,
	           "AzarTel": AzarTel, "SamaTel": SamaTel, "Lotustel": Lotustel, "shatel": shatel, "Anarestan": Anarestan}

	counter = 0
	numberList = []
	for key, value in precode.items():
		for i in value:
			counter = 0
			numberList = []
			for j in range(4782969):

				if key in ["Irancell", "MCI", "Talia", "Rightel", "spadan", "teleKish"]:
					phoneNumber = (98000 + i) * 10000000 + j
					numberList.append(phoneNumber)
					counter = counter + 1

					if counter > 20:
						data = {"Operator": key, "phone_number": numberList,'telegram_check':False}
						insert = db.phone_numbers.insert_one(data)
						counter = 0
						numberList = []


				if key in ["ApTel", "AzarTel", "SamaTel", "shatel"]:
					phoneNumber = (9800000 + i) * 10000000 + j

					numberList.append(phoneNumber)
					counter = counter + 1

					if counter > 20:
						data = {"Operator": key, "phone_number": numberList, 'telegram_check': False}
						insert = db.phone_numbers.insert_one(data)
						counter = 0
						numberList = []


				if key in ["Anarestan", "Lotustel"]:
					phoneNumber = (980000 + i) * 10000000 + j


					numberList.append(phoneNumber)
					counter = counter + 1

					if counter > 20:
						data = {"Operator": key, "phone_number": numberList, 'telegram_check': False}
						insert = db.phone_numbers.insert_one(data)
						counter = 0
						numberList = []

				printProgressBar(iteration=j, total=4782969, prefix="==> %s phone number generator" % key,suffix='complete - %d phone number generated' % int(j))




phoneNumberGenerator()